// Generated from org/kie/dmn/feel/parser/feel11/FEEL_1_1.g4 by ANTLR 4.8
package org.kie.dmn.feel.parser.feel11;

    import org.kie.dmn.feel.parser.feel11.ParserHelper;

import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link FEEL_1_1Parser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface FEEL_1_1Visitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#compilation_unit}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCompilation_unit(FEEL_1_1Parser.Compilation_unitContext ctx);
	/**
	 * Visit a parse tree produced by the {@code expressionTextual}
	 * labeled alternative in {@link FEEL_1_1Parser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpressionTextual(FEEL_1_1Parser.ExpressionTextualContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#textualExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTextualExpression(FEEL_1_1Parser.TextualExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code parametersEmpty}
	 * labeled alternative in {@link FEEL_1_1Parser#parameters}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParametersEmpty(FEEL_1_1Parser.ParametersEmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code parametersNamed}
	 * labeled alternative in {@link FEEL_1_1Parser#parameters}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParametersNamed(FEEL_1_1Parser.ParametersNamedContext ctx);
	/**
	 * Visit a parse tree produced by the {@code parametersPositional}
	 * labeled alternative in {@link FEEL_1_1Parser#parameters}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParametersPositional(FEEL_1_1Parser.ParametersPositionalContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#namedParameters}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNamedParameters(FEEL_1_1Parser.NamedParametersContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#namedParameter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNamedParameter(FEEL_1_1Parser.NamedParameterContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#positionalParameters}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPositionalParameters(FEEL_1_1Parser.PositionalParametersContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#forExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForExpression(FEEL_1_1Parser.ForExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#iterationContexts}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIterationContexts(FEEL_1_1Parser.IterationContextsContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#iterationContext}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIterationContext(FEEL_1_1Parser.IterationContextContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#ifExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfExpression(FEEL_1_1Parser.IfExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code quantExprSome}
	 * labeled alternative in {@link FEEL_1_1Parser#quantifiedExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQuantExprSome(FEEL_1_1Parser.QuantExprSomeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code quantExprEvery}
	 * labeled alternative in {@link FEEL_1_1Parser#quantifiedExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQuantExprEvery(FEEL_1_1Parser.QuantExprEveryContext ctx);
	/**
	 * Visit a parse tree produced by the {@code listType}
	 * labeled alternative in {@link FEEL_1_1Parser#type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitListType(FEEL_1_1Parser.ListTypeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code contextType}
	 * labeled alternative in {@link FEEL_1_1Parser#type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitContextType(FEEL_1_1Parser.ContextTypeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code qnType}
	 * labeled alternative in {@link FEEL_1_1Parser#type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQnType(FEEL_1_1Parser.QnTypeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code functionType}
	 * labeled alternative in {@link FEEL_1_1Parser#type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctionType(FEEL_1_1Parser.FunctionTypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitList(FEEL_1_1Parser.ListContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#functionDefinition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctionDefinition(FEEL_1_1Parser.FunctionDefinitionContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#formalParameters}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFormalParameters(FEEL_1_1Parser.FormalParametersContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#formalParameter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFormalParameter(FEEL_1_1Parser.FormalParameterContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#context}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitContext(FEEL_1_1Parser.ContextContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#contextEntries}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitContextEntries(FEEL_1_1Parser.ContextEntriesContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#contextEntry}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitContextEntry(FEEL_1_1Parser.ContextEntryContext ctx);
	/**
	 * Visit a parse tree produced by the {@code keyName}
	 * labeled alternative in {@link FEEL_1_1Parser#key}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitKeyName(FEEL_1_1Parser.KeyNameContext ctx);
	/**
	 * Visit a parse tree produced by the {@code keyString}
	 * labeled alternative in {@link FEEL_1_1Parser#key}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitKeyString(FEEL_1_1Parser.KeyStringContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#nameDefinition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNameDefinition(FEEL_1_1Parser.NameDefinitionContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#nameDefinitionWithEOF}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNameDefinitionWithEOF(FEEL_1_1Parser.NameDefinitionWithEOFContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#nameDefinitionTokens}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNameDefinitionTokens(FEEL_1_1Parser.NameDefinitionTokensContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#iterationNameDefinition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIterationNameDefinition(FEEL_1_1Parser.IterationNameDefinitionContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#iterationNameDefinitionTokens}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIterationNameDefinitionTokens(FEEL_1_1Parser.IterationNameDefinitionTokensContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#additionalNameSymbol}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAdditionalNameSymbol(FEEL_1_1Parser.AdditionalNameSymbolContext ctx);
	/**
	 * Visit a parse tree produced by the {@code condOr}
	 * labeled alternative in {@link FEEL_1_1Parser#conditionalOrExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCondOr(FEEL_1_1Parser.CondOrContext ctx);
	/**
	 * Visit a parse tree produced by the {@code condOrAnd}
	 * labeled alternative in {@link FEEL_1_1Parser#conditionalOrExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCondOrAnd(FEEL_1_1Parser.CondOrAndContext ctx);
	/**
	 * Visit a parse tree produced by the {@code condAndComp}
	 * labeled alternative in {@link FEEL_1_1Parser#conditionalAndExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCondAndComp(FEEL_1_1Parser.CondAndCompContext ctx);
	/**
	 * Visit a parse tree produced by the {@code condAnd}
	 * labeled alternative in {@link FEEL_1_1Parser#conditionalAndExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCondAnd(FEEL_1_1Parser.CondAndContext ctx);
	/**
	 * Visit a parse tree produced by the {@code compExpression}
	 * labeled alternative in {@link FEEL_1_1Parser#comparisonExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCompExpression(FEEL_1_1Parser.CompExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code compExpressionRel}
	 * labeled alternative in {@link FEEL_1_1Parser#comparisonExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCompExpressionRel(FEEL_1_1Parser.CompExpressionRelContext ctx);
	/**
	 * Visit a parse tree produced by the {@code relExpressionBetween}
	 * labeled alternative in {@link FEEL_1_1Parser#relationalExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRelExpressionBetween(FEEL_1_1Parser.RelExpressionBetweenContext ctx);
	/**
	 * Visit a parse tree produced by the {@code relExpressionValue}
	 * labeled alternative in {@link FEEL_1_1Parser#relationalExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRelExpressionValue(FEEL_1_1Parser.RelExpressionValueContext ctx);
	/**
	 * Visit a parse tree produced by the {@code relExpressionTestList}
	 * labeled alternative in {@link FEEL_1_1Parser#relationalExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRelExpressionTestList(FEEL_1_1Parser.RelExpressionTestListContext ctx);
	/**
	 * Visit a parse tree produced by the {@code relExpressionAdd}
	 * labeled alternative in {@link FEEL_1_1Parser#relationalExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRelExpressionAdd(FEEL_1_1Parser.RelExpressionAddContext ctx);
	/**
	 * Visit a parse tree produced by the {@code relExpressionInstanceOf}
	 * labeled alternative in {@link FEEL_1_1Parser#relationalExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRelExpressionInstanceOf(FEEL_1_1Parser.RelExpressionInstanceOfContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#expressionList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpressionList(FEEL_1_1Parser.ExpressionListContext ctx);
	/**
	 * Visit a parse tree produced by the {@code addExpressionMult}
	 * labeled alternative in {@link FEEL_1_1Parser#additiveExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAddExpressionMult(FEEL_1_1Parser.AddExpressionMultContext ctx);
	/**
	 * Visit a parse tree produced by the {@code addExpression}
	 * labeled alternative in {@link FEEL_1_1Parser#additiveExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAddExpression(FEEL_1_1Parser.AddExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code multExpressionPow}
	 * labeled alternative in {@link FEEL_1_1Parser#multiplicativeExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMultExpressionPow(FEEL_1_1Parser.MultExpressionPowContext ctx);
	/**
	 * Visit a parse tree produced by the {@code multExpression}
	 * labeled alternative in {@link FEEL_1_1Parser#multiplicativeExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMultExpression(FEEL_1_1Parser.MultExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code powExpressionUnary}
	 * labeled alternative in {@link FEEL_1_1Parser#powerExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPowExpressionUnary(FEEL_1_1Parser.PowExpressionUnaryContext ctx);
	/**
	 * Visit a parse tree produced by the {@code powExpression}
	 * labeled alternative in {@link FEEL_1_1Parser#powerExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPowExpression(FEEL_1_1Parser.PowExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#filterPathExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFilterPathExpression(FEEL_1_1Parser.FilterPathExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code signedUnaryExpressionPlus}
	 * labeled alternative in {@link FEEL_1_1Parser#unaryExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSignedUnaryExpressionPlus(FEEL_1_1Parser.SignedUnaryExpressionPlusContext ctx);
	/**
	 * Visit a parse tree produced by the {@code signedUnaryExpressionMinus}
	 * labeled alternative in {@link FEEL_1_1Parser#unaryExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSignedUnaryExpressionMinus(FEEL_1_1Parser.SignedUnaryExpressionMinusContext ctx);
	/**
	 * Visit a parse tree produced by the {@code fnInvocation}
	 * labeled alternative in {@link FEEL_1_1Parser#unaryExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFnInvocation(FEEL_1_1Parser.FnInvocationContext ctx);
	/**
	 * Visit a parse tree produced by the {@code nonSignedUnaryExpression}
	 * labeled alternative in {@link FEEL_1_1Parser#unaryExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNonSignedUnaryExpression(FEEL_1_1Parser.NonSignedUnaryExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code uenpmPrimary}
	 * labeled alternative in {@link FEEL_1_1Parser#unaryExpressionNotPlusMinus}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUenpmPrimary(FEEL_1_1Parser.UenpmPrimaryContext ctx);
	/**
	 * Visit a parse tree produced by the {@code primaryLiteral}
	 * labeled alternative in {@link FEEL_1_1Parser#primary}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrimaryLiteral(FEEL_1_1Parser.PrimaryLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code primaryForExpression}
	 * labeled alternative in {@link FEEL_1_1Parser#primary}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrimaryForExpression(FEEL_1_1Parser.PrimaryForExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code primaryQuantifiedExpression}
	 * labeled alternative in {@link FEEL_1_1Parser#primary}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrimaryQuantifiedExpression(FEEL_1_1Parser.PrimaryQuantifiedExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code primaryIfExpression}
	 * labeled alternative in {@link FEEL_1_1Parser#primary}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrimaryIfExpression(FEEL_1_1Parser.PrimaryIfExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code primaryInterval}
	 * labeled alternative in {@link FEEL_1_1Parser#primary}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrimaryInterval(FEEL_1_1Parser.PrimaryIntervalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code primaryList}
	 * labeled alternative in {@link FEEL_1_1Parser#primary}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrimaryList(FEEL_1_1Parser.PrimaryListContext ctx);
	/**
	 * Visit a parse tree produced by the {@code primaryContext}
	 * labeled alternative in {@link FEEL_1_1Parser#primary}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrimaryContext(FEEL_1_1Parser.PrimaryContextContext ctx);
	/**
	 * Visit a parse tree produced by the {@code primaryParens}
	 * labeled alternative in {@link FEEL_1_1Parser#primary}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrimaryParens(FEEL_1_1Parser.PrimaryParensContext ctx);
	/**
	 * Visit a parse tree produced by the {@code primaryUnaryTest}
	 * labeled alternative in {@link FEEL_1_1Parser#primary}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrimaryUnaryTest(FEEL_1_1Parser.PrimaryUnaryTestContext ctx);
	/**
	 * Visit a parse tree produced by the {@code primaryName}
	 * labeled alternative in {@link FEEL_1_1Parser#primary}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrimaryName(FEEL_1_1Parser.PrimaryNameContext ctx);
	/**
	 * Visit a parse tree produced by the {@code numberLiteral}
	 * labeled alternative in {@link FEEL_1_1Parser#literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumberLiteral(FEEL_1_1Parser.NumberLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code boolLiteral}
	 * labeled alternative in {@link FEEL_1_1Parser#literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolLiteral(FEEL_1_1Parser.BoolLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code atLiteralLabel}
	 * labeled alternative in {@link FEEL_1_1Parser#literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAtLiteralLabel(FEEL_1_1Parser.AtLiteralLabelContext ctx);
	/**
	 * Visit a parse tree produced by the {@code stringLiteral}
	 * labeled alternative in {@link FEEL_1_1Parser#literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringLiteral(FEEL_1_1Parser.StringLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code nullLiteral}
	 * labeled alternative in {@link FEEL_1_1Parser#literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNullLiteral(FEEL_1_1Parser.NullLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#atLiteral}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAtLiteral(FEEL_1_1Parser.AtLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#atLiteralValue}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAtLiteralValue(FEEL_1_1Parser.AtLiteralValueContext ctx);
	/**
	 * Visit a parse tree produced by the {@code positiveUnaryTestIneqInterval}
	 * labeled alternative in {@link FEEL_1_1Parser#simplePositiveUnaryTest}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPositiveUnaryTestIneqInterval(FEEL_1_1Parser.PositiveUnaryTestIneqIntervalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code positiveUnaryTestIneq}
	 * labeled alternative in {@link FEEL_1_1Parser#simplePositiveUnaryTest}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPositiveUnaryTestIneq(FEEL_1_1Parser.PositiveUnaryTestIneqContext ctx);
	/**
	 * Visit a parse tree produced by the {@code positiveUnaryTestInterval}
	 * labeled alternative in {@link FEEL_1_1Parser#simplePositiveUnaryTest}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPositiveUnaryTestInterval(FEEL_1_1Parser.PositiveUnaryTestIntervalContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#simplePositiveUnaryTests}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSimplePositiveUnaryTests(FEEL_1_1Parser.SimplePositiveUnaryTestsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code positiveSimplePositiveUnaryTests}
	 * labeled alternative in {@link FEEL_1_1Parser#simpleUnaryTests}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPositiveSimplePositiveUnaryTests(FEEL_1_1Parser.PositiveSimplePositiveUnaryTestsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code negatedSimplePositiveUnaryTests}
	 * labeled alternative in {@link FEEL_1_1Parser#simpleUnaryTests}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNegatedSimplePositiveUnaryTests(FEEL_1_1Parser.NegatedSimplePositiveUnaryTestsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code positiveUnaryTestDash}
	 * labeled alternative in {@link FEEL_1_1Parser#simpleUnaryTests}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPositiveUnaryTestDash(FEEL_1_1Parser.PositiveUnaryTestDashContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#positiveUnaryTest}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPositiveUnaryTest(FEEL_1_1Parser.PositiveUnaryTestContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#positiveUnaryTests}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPositiveUnaryTests(FEEL_1_1Parser.PositiveUnaryTestsContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#unaryTestsRoot}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryTestsRoot(FEEL_1_1Parser.UnaryTestsRootContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryTests_negated}
	 * labeled alternative in {@link FEEL_1_1Parser#unaryTests}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryTests_negated(FEEL_1_1Parser.UnaryTests_negatedContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryTests_positive}
	 * labeled alternative in {@link FEEL_1_1Parser#unaryTests}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryTests_positive(FEEL_1_1Parser.UnaryTests_positiveContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryTests_empty}
	 * labeled alternative in {@link FEEL_1_1Parser#unaryTests}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryTests_empty(FEEL_1_1Parser.UnaryTests_emptyContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#endpoint}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEndpoint(FEEL_1_1Parser.EndpointContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#interval}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInterval(FEEL_1_1Parser.IntervalContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#qualifiedName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQualifiedName(FEEL_1_1Parser.QualifiedNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#nameRef}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNameRef(FEEL_1_1Parser.NameRefContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#nameRefOtherToken}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNameRefOtherToken(FEEL_1_1Parser.NameRefOtherTokenContext ctx);
	/**
	 * Visit a parse tree produced by {@link FEEL_1_1Parser#reusableKeywords}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReusableKeywords(FEEL_1_1Parser.ReusableKeywordsContext ctx);
}