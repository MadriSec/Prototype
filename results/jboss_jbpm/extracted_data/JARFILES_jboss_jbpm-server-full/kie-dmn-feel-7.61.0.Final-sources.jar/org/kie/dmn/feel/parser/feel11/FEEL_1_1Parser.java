// Generated from org/kie/dmn/feel/parser/feel11/FEEL_1_1.g4 by ANTLR 4.8
package org.kie.dmn.feel.parser.feel11;

    import org.kie.dmn.feel.parser.feel11.ParserHelper;

import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class FEEL_1_1Parser extends Parser {
	static { RuntimeMetaData.checkVersion("4.8", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		BooleanLiteral=1, FOR=2, RETURN=3, IN=4, IF=5, THEN=6, ELSE=7, SOME=8, 
		EVERY=9, SATISFIES=10, INSTANCE=11, OF=12, FUNCTION=13, EXTERNAL=14, OR=15, 
		AND=16, BETWEEN=17, NULL=18, TRUE=19, FALSE=20, QUOTE=21, IntegerLiteral=22, 
		FloatingPointLiteral=23, StringLiteral=24, LPAREN=25, RPAREN=26, LBRACE=27, 
		RBRACE=28, LBRACK=29, RBRACK=30, COMMA=31, ELIPSIS=32, DOT=33, EQUAL=34, 
		GT=35, LT=36, LE=37, GE=38, NOTEQUAL=39, COLON=40, RARROW=41, POW=42, 
		ADD=43, SUB=44, MUL=45, DIV=46, BANG=47, NOT=48, AT=49, Identifier=50, 
		WS=51, COMMENT=52, LINE_COMMENT=53, ANY_OTHER_CHAR=54;
	public static final int
		RULE_compilation_unit = 0, RULE_expression = 1, RULE_textualExpression = 2, 
		RULE_parameters = 3, RULE_namedParameters = 4, RULE_namedParameter = 5, 
		RULE_positionalParameters = 6, RULE_forExpression = 7, RULE_iterationContexts = 8, 
		RULE_iterationContext = 9, RULE_ifExpression = 10, RULE_quantifiedExpression = 11, 
		RULE_type = 12, RULE_list = 13, RULE_functionDefinition = 14, RULE_formalParameters = 15, 
		RULE_formalParameter = 16, RULE_context = 17, RULE_contextEntries = 18, 
		RULE_contextEntry = 19, RULE_key = 20, RULE_nameDefinition = 21, RULE_nameDefinitionWithEOF = 22, 
		RULE_nameDefinitionTokens = 23, RULE_iterationNameDefinition = 24, RULE_iterationNameDefinitionTokens = 25, 
		RULE_additionalNameSymbol = 26, RULE_conditionalOrExpression = 27, RULE_conditionalAndExpression = 28, 
		RULE_comparisonExpression = 29, RULE_relationalExpression = 30, RULE_expressionList = 31, 
		RULE_additiveExpression = 32, RULE_multiplicativeExpression = 33, RULE_powerExpression = 34, 
		RULE_filterPathExpression = 35, RULE_unaryExpression = 36, RULE_unaryExpressionNotPlusMinus = 37, 
		RULE_primary = 38, RULE_literal = 39, RULE_atLiteral = 40, RULE_atLiteralValue = 41, 
		RULE_simplePositiveUnaryTest = 42, RULE_simplePositiveUnaryTests = 43, 
		RULE_simpleUnaryTests = 44, RULE_positiveUnaryTest = 45, RULE_positiveUnaryTests = 46, 
		RULE_unaryTestsRoot = 47, RULE_unaryTests = 48, RULE_endpoint = 49, RULE_interval = 50, 
		RULE_qualifiedName = 51, RULE_nameRef = 52, RULE_nameRefOtherToken = 53, 
		RULE_reusableKeywords = 54;
	private static String[] makeRuleNames() {
		return new String[] {
			"compilation_unit", "expression", "textualExpression", "parameters", 
			"namedParameters", "namedParameter", "positionalParameters", "forExpression", 
			"iterationContexts", "iterationContext", "ifExpression", "quantifiedExpression", 
			"type", "list", "functionDefinition", "formalParameters", "formalParameter", 
			"context", "contextEntries", "contextEntry", "key", "nameDefinition", 
			"nameDefinitionWithEOF", "nameDefinitionTokens", "iterationNameDefinition", 
			"iterationNameDefinitionTokens", "additionalNameSymbol", "conditionalOrExpression", 
			"conditionalAndExpression", "comparisonExpression", "relationalExpression", 
			"expressionList", "additiveExpression", "multiplicativeExpression", "powerExpression", 
			"filterPathExpression", "unaryExpression", "unaryExpressionNotPlusMinus", 
			"primary", "literal", "atLiteral", "atLiteralValue", "simplePositiveUnaryTest", 
			"simplePositiveUnaryTests", "simpleUnaryTests", "positiveUnaryTest", 
			"positiveUnaryTests", "unaryTestsRoot", "unaryTests", "endpoint", "interval", 
			"qualifiedName", "nameRef", "nameRefOtherToken", "reusableKeywords"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, null, "'for'", "'return'", "'in'", "'if'", "'then'", "'else'", 
			"'some'", "'every'", "'satisfies'", "'instance'", "'of'", "'function'", 
			"'external'", "'or'", "'and'", "'between'", "'null'", "'true'", "'false'", 
			"'''", null, null, null, "'('", "')'", "'{'", "'}'", "'['", "']'", "','", 
			"'..'", "'.'", "'='", "'>'", "'<'", "'<='", "'>='", "'!='", "':'", "'->'", 
			"'**'", "'+'", "'-'", "'*'", "'/'", "'!'", "'not'", "'@'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "BooleanLiteral", "FOR", "RETURN", "IN", "IF", "THEN", "ELSE", 
			"SOME", "EVERY", "SATISFIES", "INSTANCE", "OF", "FUNCTION", "EXTERNAL", 
			"OR", "AND", "BETWEEN", "NULL", "TRUE", "FALSE", "QUOTE", "IntegerLiteral", 
			"FloatingPointLiteral", "StringLiteral", "LPAREN", "RPAREN", "LBRACE", 
			"RBRACE", "LBRACK", "RBRACK", "COMMA", "ELIPSIS", "DOT", "EQUAL", "GT", 
			"LT", "LE", "GE", "NOTEQUAL", "COLON", "RARROW", "POW", "ADD", "SUB", 
			"MUL", "DIV", "BANG", "NOT", "AT", "Identifier", "WS", "COMMENT", "LINE_COMMENT", 
			"ANY_OTHER_CHAR"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "FEEL_1_1.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }


	    private ParserHelper helper = null;
	    
	    public void setHelper( ParserHelper helper ) {
	        this.helper = helper;
	    }

	    public ParserHelper getHelper() {
	        return helper;
	    }

	    private String getOriginalText( ParserRuleContext ctx ) {
	        int a = ctx.start.getStartIndex();
	        int b = ctx.stop.getStopIndex();
	        Interval interval = new Interval(a,b);
	        return ctx.getStart().getInputStream().getText(interval);
	    }

	public FEEL_1_1Parser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class Compilation_unitContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode EOF() { return getToken(FEEL_1_1Parser.EOF, 0); }
		public Compilation_unitContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_compilation_unit; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitCompilation_unit(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Compilation_unitContext compilation_unit() throws RecognitionException {
		Compilation_unitContext _localctx = new Compilation_unitContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_compilation_unit);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(110);
			expression();
			setState(111);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExpressionContext extends ParserRuleContext {
		public ExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expression; }
	 
		public ExpressionContext() { }
		public void copyFrom(ExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ExpressionTextualContext extends ExpressionContext {
		public TextualExpressionContext expr;
		public TextualExpressionContext textualExpression() {
			return getRuleContext(TextualExpressionContext.class,0);
		}
		public ExpressionTextualContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitExpressionTextual(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExpressionContext expression() throws RecognitionException {
		ExpressionContext _localctx = new ExpressionContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_expression);
		try {
			_localctx = new ExpressionTextualContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(113);
			((ExpressionTextualContext)_localctx).expr = textualExpression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TextualExpressionContext extends ParserRuleContext {
		public FunctionDefinitionContext functionDefinition() {
			return getRuleContext(FunctionDefinitionContext.class,0);
		}
		public ConditionalOrExpressionContext conditionalOrExpression() {
			return getRuleContext(ConditionalOrExpressionContext.class,0);
		}
		public TextualExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_textualExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitTextualExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TextualExpressionContext textualExpression() throws RecognitionException {
		TextualExpressionContext _localctx = new TextualExpressionContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_textualExpression);
		try {
			setState(117);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case FUNCTION:
				enterOuterAlt(_localctx, 1);
				{
				setState(115);
				functionDefinition();
				}
				break;
			case BooleanLiteral:
			case FOR:
			case IF:
			case SOME:
			case EVERY:
			case NULL:
			case IntegerLiteral:
			case FloatingPointLiteral:
			case StringLiteral:
			case LPAREN:
			case LBRACE:
			case LBRACK:
			case RBRACK:
			case EQUAL:
			case GT:
			case LT:
			case LE:
			case GE:
			case NOTEQUAL:
			case ADD:
			case SUB:
			case NOT:
			case AT:
			case Identifier:
				enterOuterAlt(_localctx, 2);
				{
				setState(116);
				conditionalOrExpression(0);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ParametersContext extends ParserRuleContext {
		public ParametersContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parameters; }
	 
		public ParametersContext() { }
		public void copyFrom(ParametersContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ParametersNamedContext extends ParametersContext {
		public TerminalNode LPAREN() { return getToken(FEEL_1_1Parser.LPAREN, 0); }
		public NamedParametersContext namedParameters() {
			return getRuleContext(NamedParametersContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(FEEL_1_1Parser.RPAREN, 0); }
		public ParametersNamedContext(ParametersContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitParametersNamed(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ParametersEmptyContext extends ParametersContext {
		public TerminalNode LPAREN() { return getToken(FEEL_1_1Parser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(FEEL_1_1Parser.RPAREN, 0); }
		public ParametersEmptyContext(ParametersContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitParametersEmpty(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ParametersPositionalContext extends ParametersContext {
		public TerminalNode LPAREN() { return getToken(FEEL_1_1Parser.LPAREN, 0); }
		public PositionalParametersContext positionalParameters() {
			return getRuleContext(PositionalParametersContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(FEEL_1_1Parser.RPAREN, 0); }
		public ParametersPositionalContext(ParametersContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitParametersPositional(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParametersContext parameters() throws RecognitionException {
		ParametersContext _localctx = new ParametersContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_parameters);
		try {
			setState(129);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,1,_ctx) ) {
			case 1:
				_localctx = new ParametersEmptyContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(119);
				match(LPAREN);
				setState(120);
				match(RPAREN);
				}
				break;
			case 2:
				_localctx = new ParametersNamedContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(121);
				match(LPAREN);
				setState(122);
				namedParameters();
				setState(123);
				match(RPAREN);
				}
				break;
			case 3:
				_localctx = new ParametersPositionalContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(125);
				match(LPAREN);
				setState(126);
				positionalParameters();
				setState(127);
				match(RPAREN);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NamedParametersContext extends ParserRuleContext {
		public List<NamedParameterContext> namedParameter() {
			return getRuleContexts(NamedParameterContext.class);
		}
		public NamedParameterContext namedParameter(int i) {
			return getRuleContext(NamedParameterContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(FEEL_1_1Parser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(FEEL_1_1Parser.COMMA, i);
		}
		public NamedParametersContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_namedParameters; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitNamedParameters(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NamedParametersContext namedParameters() throws RecognitionException {
		NamedParametersContext _localctx = new NamedParametersContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_namedParameters);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(131);
			namedParameter();
			setState(136);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(132);
				match(COMMA);
				setState(133);
				namedParameter();
				}
				}
				setState(138);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NamedParameterContext extends ParserRuleContext {
		public NameDefinitionContext name;
		public ExpressionContext value;
		public TerminalNode COLON() { return getToken(FEEL_1_1Parser.COLON, 0); }
		public NameDefinitionContext nameDefinition() {
			return getRuleContext(NameDefinitionContext.class,0);
		}
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public NamedParameterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_namedParameter; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitNamedParameter(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NamedParameterContext namedParameter() throws RecognitionException {
		NamedParameterContext _localctx = new NamedParameterContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_namedParameter);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(139);
			((NamedParameterContext)_localctx).name = nameDefinition();
			setState(140);
			match(COLON);
			setState(141);
			((NamedParameterContext)_localctx).value = expression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PositionalParametersContext extends ParserRuleContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(FEEL_1_1Parser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(FEEL_1_1Parser.COMMA, i);
		}
		public PositionalParametersContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_positionalParameters; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitPositionalParameters(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PositionalParametersContext positionalParameters() throws RecognitionException {
		PositionalParametersContext _localctx = new PositionalParametersContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_positionalParameters);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(143);
			expression();
			setState(148);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(144);
				match(COMMA);
				setState(145);
				expression();
				}
				}
				setState(150);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ForExpressionContext extends ParserRuleContext {
		public TerminalNode FOR() { return getToken(FEEL_1_1Parser.FOR, 0); }
		public IterationContextsContext iterationContexts() {
			return getRuleContext(IterationContextsContext.class,0);
		}
		public TerminalNode RETURN() { return getToken(FEEL_1_1Parser.RETURN, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public ForExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_forExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitForExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ForExpressionContext forExpression() throws RecognitionException {
		ForExpressionContext _localctx = new ForExpressionContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_forExpression);

		    helper.pushScope();

		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(151);
			match(FOR);
			setState(152);
			iterationContexts();
			setState(153);
			match(RETURN);
			helper.enableDynamicResolution();
			setState(155);
			expression();
			helper.disableDynamicResolution();
			}
			_ctx.stop = _input.LT(-1);

			    helper.popScope();

		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IterationContextsContext extends ParserRuleContext {
		public List<IterationContextContext> iterationContext() {
			return getRuleContexts(IterationContextContext.class);
		}
		public IterationContextContext iterationContext(int i) {
			return getRuleContext(IterationContextContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(FEEL_1_1Parser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(FEEL_1_1Parser.COMMA, i);
		}
		public IterationContextsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_iterationContexts; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitIterationContexts(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IterationContextsContext iterationContexts() throws RecognitionException {
		IterationContextsContext _localctx = new IterationContextsContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_iterationContexts);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(158);
			iterationContext();
			setState(163);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(159);
				match(COMMA);
				setState(160);
				iterationContext();
				}
				}
				setState(165);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IterationContextContext extends ParserRuleContext {
		public IterationNameDefinitionContext iterationNameDefinition() {
			return getRuleContext(IterationNameDefinitionContext.class,0);
		}
		public TerminalNode IN() { return getToken(FEEL_1_1Parser.IN, 0); }
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode ELIPSIS() { return getToken(FEEL_1_1Parser.ELIPSIS, 0); }
		public IterationContextContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_iterationContext; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitIterationContext(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IterationContextContext iterationContext() throws RecognitionException {
		IterationContextContext _localctx = new IterationContextContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_iterationContext);
		try {
			setState(177);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,5,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(166);
				if (!(helper.isFeatDMN12EnhancedForLoopEnabled())) throw new FailedPredicateException(this, "helper.isFeatDMN12EnhancedForLoopEnabled()");
				setState(167);
				iterationNameDefinition();
				setState(168);
				match(IN);
				setState(169);
				expression();
				setState(170);
				match(ELIPSIS);
				setState(171);
				expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(173);
				iterationNameDefinition();
				setState(174);
				match(IN);
				setState(175);
				expression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IfExpressionContext extends ParserRuleContext {
		public ExpressionContext c;
		public ExpressionContext t;
		public ExpressionContext e;
		public TerminalNode IF() { return getToken(FEEL_1_1Parser.IF, 0); }
		public TerminalNode THEN() { return getToken(FEEL_1_1Parser.THEN, 0); }
		public TerminalNode ELSE() { return getToken(FEEL_1_1Parser.ELSE, 0); }
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public IfExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ifExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitIfExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IfExpressionContext ifExpression() throws RecognitionException {
		IfExpressionContext _localctx = new IfExpressionContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_ifExpression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(179);
			match(IF);
			setState(180);
			((IfExpressionContext)_localctx).c = expression();
			setState(181);
			match(THEN);
			setState(182);
			((IfExpressionContext)_localctx).t = expression();
			setState(183);
			match(ELSE);
			setState(184);
			((IfExpressionContext)_localctx).e = expression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class QuantifiedExpressionContext extends ParserRuleContext {
		public QuantifiedExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_quantifiedExpression; }
	 
		public QuantifiedExpressionContext() { }
		public void copyFrom(QuantifiedExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class QuantExprSomeContext extends QuantifiedExpressionContext {
		public TerminalNode SOME() { return getToken(FEEL_1_1Parser.SOME, 0); }
		public IterationContextsContext iterationContexts() {
			return getRuleContext(IterationContextsContext.class,0);
		}
		public TerminalNode SATISFIES() { return getToken(FEEL_1_1Parser.SATISFIES, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public QuantExprSomeContext(QuantifiedExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitQuantExprSome(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class QuantExprEveryContext extends QuantifiedExpressionContext {
		public TerminalNode EVERY() { return getToken(FEEL_1_1Parser.EVERY, 0); }
		public IterationContextsContext iterationContexts() {
			return getRuleContext(IterationContextsContext.class,0);
		}
		public TerminalNode SATISFIES() { return getToken(FEEL_1_1Parser.SATISFIES, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public QuantExprEveryContext(QuantifiedExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitQuantExprEvery(this);
			else return visitor.visitChildren(this);
		}
	}

	public final QuantifiedExpressionContext quantifiedExpression() throws RecognitionException {
		QuantifiedExpressionContext _localctx = new QuantifiedExpressionContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_quantifiedExpression);

		    helper.pushScope();

		try {
			setState(200);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SOME:
				_localctx = new QuantExprSomeContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(186);
				match(SOME);
				setState(187);
				iterationContexts();
				setState(188);
				match(SATISFIES);
				helper.enableDynamicResolution();
				setState(190);
				expression();
				helper.disableDynamicResolution();
				}
				break;
			case EVERY:
				_localctx = new QuantExprEveryContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(193);
				match(EVERY);
				setState(194);
				iterationContexts();
				setState(195);
				match(SATISFIES);
				helper.enableDynamicResolution();
				setState(197);
				expression();
				helper.disableDynamicResolution();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			_ctx.stop = _input.LT(-1);

			    helper.popScope();

		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TypeContext extends ParserRuleContext {
		public TypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type; }
	 
		public TypeContext() { }
		public void copyFrom(TypeContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ContextTypeContext extends TypeContext {
		public Token sk;
		public TerminalNode LT() { return getToken(FEEL_1_1Parser.LT, 0); }
		public List<TerminalNode> Identifier() { return getTokens(FEEL_1_1Parser.Identifier); }
		public TerminalNode Identifier(int i) {
			return getToken(FEEL_1_1Parser.Identifier, i);
		}
		public List<TerminalNode> COLON() { return getTokens(FEEL_1_1Parser.COLON); }
		public TerminalNode COLON(int i) {
			return getToken(FEEL_1_1Parser.COLON, i);
		}
		public List<TypeContext> type() {
			return getRuleContexts(TypeContext.class);
		}
		public TypeContext type(int i) {
			return getRuleContext(TypeContext.class,i);
		}
		public TerminalNode GT() { return getToken(FEEL_1_1Parser.GT, 0); }
		public List<TerminalNode> COMMA() { return getTokens(FEEL_1_1Parser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(FEEL_1_1Parser.COMMA, i);
		}
		public ContextTypeContext(TypeContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitContextType(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class FunctionTypeContext extends TypeContext {
		public TerminalNode FUNCTION() { return getToken(FEEL_1_1Parser.FUNCTION, 0); }
		public TerminalNode LT() { return getToken(FEEL_1_1Parser.LT, 0); }
		public List<TypeContext> type() {
			return getRuleContexts(TypeContext.class);
		}
		public TypeContext type(int i) {
			return getRuleContext(TypeContext.class,i);
		}
		public TerminalNode GT() { return getToken(FEEL_1_1Parser.GT, 0); }
		public TerminalNode RARROW() { return getToken(FEEL_1_1Parser.RARROW, 0); }
		public List<TerminalNode> COMMA() { return getTokens(FEEL_1_1Parser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(FEEL_1_1Parser.COMMA, i);
		}
		public FunctionTypeContext(TypeContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitFunctionType(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ListTypeContext extends TypeContext {
		public Token sk;
		public TerminalNode LT() { return getToken(FEEL_1_1Parser.LT, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode GT() { return getToken(FEEL_1_1Parser.GT, 0); }
		public TerminalNode Identifier() { return getToken(FEEL_1_1Parser.Identifier, 0); }
		public ListTypeContext(TypeContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitListType(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class QnTypeContext extends TypeContext {
		public TerminalNode FUNCTION() { return getToken(FEEL_1_1Parser.FUNCTION, 0); }
		public QualifiedNameContext qualifiedName() {
			return getRuleContext(QualifiedNameContext.class,0);
		}
		public QnTypeContext(TypeContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitQnType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TypeContext type() throws RecognitionException {
		TypeContext _localctx = new TypeContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_type);

		    helper.pushTypeScope();

		int _la;
		try {
			setState(241);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,9,_ctx) ) {
			case 1:
				_localctx = new ListTypeContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(202);
				((ListTypeContext)_localctx).sk = match(Identifier);
				((ListTypeContext)_localctx).sk.getText().equals("list");
				setState(204);
				match(LT);
				setState(205);
				type();
				setState(206);
				match(GT);
				}
				break;
			case 2:
				_localctx = new ContextTypeContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(208);
				((ContextTypeContext)_localctx).sk = match(Identifier);
				((ContextTypeContext)_localctx).sk.getText().equals("context");
				setState(210);
				match(LT);
				setState(211);
				match(Identifier);
				setState(212);
				match(COLON);
				setState(213);
				type();
				setState(220);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(214);
					match(COMMA);
					setState(215);
					match(Identifier);
					setState(216);
					match(COLON);
					setState(217);
					type();
					}
					}
					setState(222);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(223);
				match(GT);
				}
				break;
			case 3:
				_localctx = new QnTypeContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(225);
				match(FUNCTION);
				}
				break;
			case 4:
				_localctx = new FunctionTypeContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(226);
				match(FUNCTION);
				setState(227);
				match(LT);
				setState(228);
				type();
				setState(233);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(229);
					match(COMMA);
					setState(230);
					type();
					}
					}
					setState(235);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(236);
				match(GT);
				setState(237);
				match(RARROW);
				setState(238);
				type();
				}
				break;
			case 5:
				_localctx = new QnTypeContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(240);
				qualifiedName();
				}
				break;
			}
			_ctx.stop = _input.LT(-1);

			    helper.popScope();

		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ListContext extends ParserRuleContext {
		public TerminalNode LBRACK() { return getToken(FEEL_1_1Parser.LBRACK, 0); }
		public TerminalNode RBRACK() { return getToken(FEEL_1_1Parser.RBRACK, 0); }
		public ExpressionListContext expressionList() {
			return getRuleContext(ExpressionListContext.class,0);
		}
		public ListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_list; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ListContext list() throws RecognitionException {
		ListContext _localctx = new ListContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_list);
		try {
			setState(249);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,10,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(243);
				match(LBRACK);
				setState(244);
				match(RBRACK);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(245);
				match(LBRACK);
				setState(246);
				expressionList();
				setState(247);
				match(RBRACK);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FunctionDefinitionContext extends ParserRuleContext {
		public Token external;
		public ExpressionContext body;
		public TerminalNode FUNCTION() { return getToken(FEEL_1_1Parser.FUNCTION, 0); }
		public TerminalNode LPAREN() { return getToken(FEEL_1_1Parser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(FEEL_1_1Parser.RPAREN, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public FormalParametersContext formalParameters() {
			return getRuleContext(FormalParametersContext.class,0);
		}
		public TerminalNode EXTERNAL() { return getToken(FEEL_1_1Parser.EXTERNAL, 0); }
		public FunctionDefinitionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_functionDefinition; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitFunctionDefinition(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FunctionDefinitionContext functionDefinition() throws RecognitionException {
		FunctionDefinitionContext _localctx = new FunctionDefinitionContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_functionDefinition);

		    helper.pushScope();

		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(251);
			match(FUNCTION);
			setState(252);
			match(LPAREN);
			setState(254);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==Identifier) {
				{
				setState(253);
				formalParameters();
				}
			}

			setState(256);
			match(RPAREN);
			setState(258);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==EXTERNAL) {
				{
				setState(257);
				((FunctionDefinitionContext)_localctx).external = match(EXTERNAL);
				}
			}

			helper.enableDynamicResolution();
			setState(261);
			((FunctionDefinitionContext)_localctx).body = expression();
			helper.disableDynamicResolution();
			}
			_ctx.stop = _input.LT(-1);

			    helper.popScope();

		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FormalParametersContext extends ParserRuleContext {
		public List<FormalParameterContext> formalParameter() {
			return getRuleContexts(FormalParameterContext.class);
		}
		public FormalParameterContext formalParameter(int i) {
			return getRuleContext(FormalParameterContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(FEEL_1_1Parser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(FEEL_1_1Parser.COMMA, i);
		}
		public FormalParametersContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_formalParameters; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitFormalParameters(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FormalParametersContext formalParameters() throws RecognitionException {
		FormalParametersContext _localctx = new FormalParametersContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_formalParameters);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(264);
			formalParameter();
			setState(269);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(265);
				match(COMMA);
				setState(266);
				formalParameter();
				}
				}
				setState(271);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FormalParameterContext extends ParserRuleContext {
		public NameDefinitionContext nameDefinition() {
			return getRuleContext(NameDefinitionContext.class,0);
		}
		public TerminalNode COLON() { return getToken(FEEL_1_1Parser.COLON, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public FormalParameterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_formalParameter; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitFormalParameter(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FormalParameterContext formalParameter() throws RecognitionException {
		FormalParameterContext _localctx = new FormalParameterContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_formalParameter);
		try {
			setState(277);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,14,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(272);
				nameDefinition();
				setState(273);
				match(COLON);
				setState(274);
				type();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(276);
				nameDefinition();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ContextContext extends ParserRuleContext {
		public TerminalNode LBRACE() { return getToken(FEEL_1_1Parser.LBRACE, 0); }
		public TerminalNode RBRACE() { return getToken(FEEL_1_1Parser.RBRACE, 0); }
		public ContextEntriesContext contextEntries() {
			return getRuleContext(ContextEntriesContext.class,0);
		}
		public ContextContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_context; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitContext(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ContextContext context() throws RecognitionException {
		ContextContext _localctx = new ContextContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_context);

		    helper.pushScope();

		try {
			setState(285);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,15,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(279);
				match(LBRACE);
				setState(280);
				match(RBRACE);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(281);
				match(LBRACE);
				setState(282);
				contextEntries();
				setState(283);
				match(RBRACE);
				}
				break;
			}
			_ctx.stop = _input.LT(-1);

			    helper.popScope();

		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ContextEntriesContext extends ParserRuleContext {
		public List<ContextEntryContext> contextEntry() {
			return getRuleContexts(ContextEntryContext.class);
		}
		public ContextEntryContext contextEntry(int i) {
			return getRuleContext(ContextEntryContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(FEEL_1_1Parser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(FEEL_1_1Parser.COMMA, i);
		}
		public ContextEntriesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_contextEntries; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitContextEntries(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ContextEntriesContext contextEntries() throws RecognitionException {
		ContextEntriesContext _localctx = new ContextEntriesContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_contextEntries);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(287);
			contextEntry();
			setState(292);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(288);
				match(COMMA);
				setState(289);
				contextEntry();
				}
				}
				setState(294);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ContextEntryContext extends ParserRuleContext {
		public KeyContext key;
		public KeyContext key() {
			return getRuleContext(KeyContext.class,0);
		}
		public TerminalNode COLON() { return getToken(FEEL_1_1Parser.COLON, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public ContextEntryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_contextEntry; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitContextEntry(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ContextEntryContext contextEntry() throws RecognitionException {
		ContextEntryContext _localctx = new ContextEntryContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_contextEntry);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(295);
			((ContextEntryContext)_localctx).key = key();
			 helper.pushName( ((ContextEntryContext)_localctx).key ); 
			setState(297);
			match(COLON);
			setState(298);
			expression();
			 helper.popName(); helper.defineVariable( ((ContextEntryContext)_localctx).key ); 
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class KeyContext extends ParserRuleContext {
		public KeyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_key; }
	 
		public KeyContext() { }
		public void copyFrom(KeyContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class KeyNameContext extends KeyContext {
		public NameDefinitionContext nameDefinition() {
			return getRuleContext(NameDefinitionContext.class,0);
		}
		public KeyNameContext(KeyContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitKeyName(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class KeyStringContext extends KeyContext {
		public TerminalNode StringLiteral() { return getToken(FEEL_1_1Parser.StringLiteral, 0); }
		public KeyStringContext(KeyContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitKeyString(this);
			else return visitor.visitChildren(this);
		}
	}

	public final KeyContext key() throws RecognitionException {
		KeyContext _localctx = new KeyContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_key);
		try {
			setState(303);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case Identifier:
				_localctx = new KeyNameContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(301);
				nameDefinition();
				}
				break;
			case StringLiteral:
				_localctx = new KeyStringContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(302);
				match(StringLiteral);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NameDefinitionContext extends ParserRuleContext {
		public NameDefinitionTokensContext nameDefinitionTokens;
		public NameDefinitionTokensContext nameDefinitionTokens() {
			return getRuleContext(NameDefinitionTokensContext.class,0);
		}
		public NameDefinitionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_nameDefinition; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitNameDefinition(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NameDefinitionContext nameDefinition() throws RecognitionException {
		NameDefinitionContext _localctx = new NameDefinitionContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_nameDefinition);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(305);
			((NameDefinitionContext)_localctx).nameDefinitionTokens = nameDefinitionTokens();
			 helper.defineVariable( ((NameDefinitionContext)_localctx).nameDefinitionTokens ); 
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NameDefinitionWithEOFContext extends ParserRuleContext {
		public NameDefinitionContext nameDefinition() {
			return getRuleContext(NameDefinitionContext.class,0);
		}
		public TerminalNode EOF() { return getToken(FEEL_1_1Parser.EOF, 0); }
		public NameDefinitionWithEOFContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_nameDefinitionWithEOF; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitNameDefinitionWithEOF(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NameDefinitionWithEOFContext nameDefinitionWithEOF() throws RecognitionException {
		NameDefinitionWithEOFContext _localctx = new NameDefinitionWithEOFContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_nameDefinitionWithEOF);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(308);
			nameDefinition();
			setState(309);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NameDefinitionTokensContext extends ParserRuleContext {
		public List<TerminalNode> Identifier() { return getTokens(FEEL_1_1Parser.Identifier); }
		public TerminalNode Identifier(int i) {
			return getToken(FEEL_1_1Parser.Identifier, i);
		}
		public List<AdditionalNameSymbolContext> additionalNameSymbol() {
			return getRuleContexts(AdditionalNameSymbolContext.class);
		}
		public AdditionalNameSymbolContext additionalNameSymbol(int i) {
			return getRuleContext(AdditionalNameSymbolContext.class,i);
		}
		public List<TerminalNode> IntegerLiteral() { return getTokens(FEEL_1_1Parser.IntegerLiteral); }
		public TerminalNode IntegerLiteral(int i) {
			return getToken(FEEL_1_1Parser.IntegerLiteral, i);
		}
		public List<TerminalNode> FloatingPointLiteral() { return getTokens(FEEL_1_1Parser.FloatingPointLiteral); }
		public TerminalNode FloatingPointLiteral(int i) {
			return getToken(FEEL_1_1Parser.FloatingPointLiteral, i);
		}
		public List<ReusableKeywordsContext> reusableKeywords() {
			return getRuleContexts(ReusableKeywordsContext.class);
		}
		public ReusableKeywordsContext reusableKeywords(int i) {
			return getRuleContext(ReusableKeywordsContext.class,i);
		}
		public List<TerminalNode> IN() { return getTokens(FEEL_1_1Parser.IN); }
		public TerminalNode IN(int i) {
			return getToken(FEEL_1_1Parser.IN, i);
		}
		public NameDefinitionTokensContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_nameDefinitionTokens; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitNameDefinitionTokens(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NameDefinitionTokensContext nameDefinitionTokens() throws RecognitionException {
		NameDefinitionTokensContext _localctx = new NameDefinitionTokensContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_nameDefinitionTokens);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(311);
			match(Identifier);
			setState(320);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << FOR) | (1L << RETURN) | (1L << IN) | (1L << IF) | (1L << THEN) | (1L << ELSE) | (1L << SOME) | (1L << EVERY) | (1L << SATISFIES) | (1L << INSTANCE) | (1L << OF) | (1L << FUNCTION) | (1L << EXTERNAL) | (1L << OR) | (1L << AND) | (1L << BETWEEN) | (1L << NULL) | (1L << TRUE) | (1L << FALSE) | (1L << QUOTE) | (1L << IntegerLiteral) | (1L << FloatingPointLiteral) | (1L << DOT) | (1L << ADD) | (1L << SUB) | (1L << MUL) | (1L << DIV) | (1L << NOT) | (1L << Identifier))) != 0)) {
				{
				setState(318);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case Identifier:
					{
					setState(312);
					match(Identifier);
					}
					break;
				case QUOTE:
				case DOT:
				case ADD:
				case SUB:
				case MUL:
				case DIV:
					{
					setState(313);
					additionalNameSymbol();
					}
					break;
				case IntegerLiteral:
					{
					setState(314);
					match(IntegerLiteral);
					}
					break;
				case FloatingPointLiteral:
					{
					setState(315);
					match(FloatingPointLiteral);
					}
					break;
				case FOR:
				case RETURN:
				case IF:
				case THEN:
				case ELSE:
				case SOME:
				case EVERY:
				case SATISFIES:
				case INSTANCE:
				case OF:
				case FUNCTION:
				case EXTERNAL:
				case OR:
				case AND:
				case BETWEEN:
				case NULL:
				case TRUE:
				case FALSE:
				case NOT:
					{
					setState(316);
					reusableKeywords();
					}
					break;
				case IN:
					{
					setState(317);
					match(IN);
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(322);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IterationNameDefinitionContext extends ParserRuleContext {
		public IterationNameDefinitionTokensContext iterationNameDefinitionTokens;
		public IterationNameDefinitionTokensContext iterationNameDefinitionTokens() {
			return getRuleContext(IterationNameDefinitionTokensContext.class,0);
		}
		public IterationNameDefinitionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_iterationNameDefinition; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitIterationNameDefinition(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IterationNameDefinitionContext iterationNameDefinition() throws RecognitionException {
		IterationNameDefinitionContext _localctx = new IterationNameDefinitionContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_iterationNameDefinition);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(323);
			((IterationNameDefinitionContext)_localctx).iterationNameDefinitionTokens = iterationNameDefinitionTokens();
			 helper.defineVariable( ((IterationNameDefinitionContext)_localctx).iterationNameDefinitionTokens ); 
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IterationNameDefinitionTokensContext extends ParserRuleContext {
		public List<TerminalNode> Identifier() { return getTokens(FEEL_1_1Parser.Identifier); }
		public TerminalNode Identifier(int i) {
			return getToken(FEEL_1_1Parser.Identifier, i);
		}
		public List<AdditionalNameSymbolContext> additionalNameSymbol() {
			return getRuleContexts(AdditionalNameSymbolContext.class);
		}
		public AdditionalNameSymbolContext additionalNameSymbol(int i) {
			return getRuleContext(AdditionalNameSymbolContext.class,i);
		}
		public List<TerminalNode> IntegerLiteral() { return getTokens(FEEL_1_1Parser.IntegerLiteral); }
		public TerminalNode IntegerLiteral(int i) {
			return getToken(FEEL_1_1Parser.IntegerLiteral, i);
		}
		public List<TerminalNode> FloatingPointLiteral() { return getTokens(FEEL_1_1Parser.FloatingPointLiteral); }
		public TerminalNode FloatingPointLiteral(int i) {
			return getToken(FEEL_1_1Parser.FloatingPointLiteral, i);
		}
		public List<ReusableKeywordsContext> reusableKeywords() {
			return getRuleContexts(ReusableKeywordsContext.class);
		}
		public ReusableKeywordsContext reusableKeywords(int i) {
			return getRuleContext(ReusableKeywordsContext.class,i);
		}
		public IterationNameDefinitionTokensContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_iterationNameDefinitionTokens; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitIterationNameDefinitionTokens(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IterationNameDefinitionTokensContext iterationNameDefinitionTokens() throws RecognitionException {
		IterationNameDefinitionTokensContext _localctx = new IterationNameDefinitionTokensContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_iterationNameDefinitionTokens);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(326);
			match(Identifier);
			setState(334);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << FOR) | (1L << RETURN) | (1L << IF) | (1L << THEN) | (1L << ELSE) | (1L << SOME) | (1L << EVERY) | (1L << SATISFIES) | (1L << INSTANCE) | (1L << OF) | (1L << FUNCTION) | (1L << EXTERNAL) | (1L << OR) | (1L << AND) | (1L << BETWEEN) | (1L << NULL) | (1L << TRUE) | (1L << FALSE) | (1L << QUOTE) | (1L << IntegerLiteral) | (1L << FloatingPointLiteral) | (1L << DOT) | (1L << ADD) | (1L << SUB) | (1L << MUL) | (1L << DIV) | (1L << NOT) | (1L << Identifier))) != 0)) {
				{
				setState(332);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case Identifier:
					{
					setState(327);
					match(Identifier);
					}
					break;
				case QUOTE:
				case DOT:
				case ADD:
				case SUB:
				case MUL:
				case DIV:
					{
					setState(328);
					additionalNameSymbol();
					}
					break;
				case IntegerLiteral:
					{
					setState(329);
					match(IntegerLiteral);
					}
					break;
				case FloatingPointLiteral:
					{
					setState(330);
					match(FloatingPointLiteral);
					}
					break;
				case FOR:
				case RETURN:
				case IF:
				case THEN:
				case ELSE:
				case SOME:
				case EVERY:
				case SATISFIES:
				case INSTANCE:
				case OF:
				case FUNCTION:
				case EXTERNAL:
				case OR:
				case AND:
				case BETWEEN:
				case NULL:
				case TRUE:
				case FALSE:
				case NOT:
					{
					setState(331);
					reusableKeywords();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(336);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AdditionalNameSymbolContext extends ParserRuleContext {
		public TerminalNode DOT() { return getToken(FEEL_1_1Parser.DOT, 0); }
		public TerminalNode DIV() { return getToken(FEEL_1_1Parser.DIV, 0); }
		public TerminalNode SUB() { return getToken(FEEL_1_1Parser.SUB, 0); }
		public TerminalNode ADD() { return getToken(FEEL_1_1Parser.ADD, 0); }
		public TerminalNode MUL() { return getToken(FEEL_1_1Parser.MUL, 0); }
		public TerminalNode QUOTE() { return getToken(FEEL_1_1Parser.QUOTE, 0); }
		public AdditionalNameSymbolContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_additionalNameSymbol; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitAdditionalNameSymbol(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AdditionalNameSymbolContext additionalNameSymbol() throws RecognitionException {
		AdditionalNameSymbolContext _localctx = new AdditionalNameSymbolContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_additionalNameSymbol);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(337);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << QUOTE) | (1L << DOT) | (1L << ADD) | (1L << SUB) | (1L << MUL) | (1L << DIV))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ConditionalOrExpressionContext extends ParserRuleContext {
		public ConditionalOrExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conditionalOrExpression; }
	 
		public ConditionalOrExpressionContext() { }
		public void copyFrom(ConditionalOrExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class CondOrContext extends ConditionalOrExpressionContext {
		public ConditionalOrExpressionContext left;
		public Token op;
		public ConditionalAndExpressionContext right;
		public ConditionalOrExpressionContext conditionalOrExpression() {
			return getRuleContext(ConditionalOrExpressionContext.class,0);
		}
		public TerminalNode OR() { return getToken(FEEL_1_1Parser.OR, 0); }
		public ConditionalAndExpressionContext conditionalAndExpression() {
			return getRuleContext(ConditionalAndExpressionContext.class,0);
		}
		public CondOrContext(ConditionalOrExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitCondOr(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class CondOrAndContext extends ConditionalOrExpressionContext {
		public ConditionalAndExpressionContext conditionalAndExpression() {
			return getRuleContext(ConditionalAndExpressionContext.class,0);
		}
		public CondOrAndContext(ConditionalOrExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitCondOrAnd(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConditionalOrExpressionContext conditionalOrExpression() throws RecognitionException {
		return conditionalOrExpression(0);
	}

	private ConditionalOrExpressionContext conditionalOrExpression(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ConditionalOrExpressionContext _localctx = new ConditionalOrExpressionContext(_ctx, _parentState);
		ConditionalOrExpressionContext _prevctx = _localctx;
		int _startState = 54;
		enterRecursionRule(_localctx, 54, RULE_conditionalOrExpression, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			_localctx = new CondOrAndContext(_localctx);
			_ctx = _localctx;
			_prevctx = _localctx;

			setState(340);
			conditionalAndExpression(0);
			}
			_ctx.stop = _input.LT(-1);
			setState(347);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,22,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new CondOrContext(new ConditionalOrExpressionContext(_parentctx, _parentState));
					((CondOrContext)_localctx).left = _prevctx;
					pushNewRecursionContext(_localctx, _startState, RULE_conditionalOrExpression);
					setState(342);
					if (!(precpred(_ctx, 1))) throw new FailedPredicateException(this, "precpred(_ctx, 1)");
					setState(343);
					((CondOrContext)_localctx).op = match(OR);
					setState(344);
					((CondOrContext)_localctx).right = conditionalAndExpression(0);
					}
					} 
				}
				setState(349);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,22,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class ConditionalAndExpressionContext extends ParserRuleContext {
		public ConditionalAndExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conditionalAndExpression; }
	 
		public ConditionalAndExpressionContext() { }
		public void copyFrom(ConditionalAndExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class CondAndCompContext extends ConditionalAndExpressionContext {
		public ComparisonExpressionContext comparisonExpression() {
			return getRuleContext(ComparisonExpressionContext.class,0);
		}
		public CondAndCompContext(ConditionalAndExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitCondAndComp(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class CondAndContext extends ConditionalAndExpressionContext {
		public ConditionalAndExpressionContext left;
		public Token op;
		public ComparisonExpressionContext right;
		public ConditionalAndExpressionContext conditionalAndExpression() {
			return getRuleContext(ConditionalAndExpressionContext.class,0);
		}
		public TerminalNode AND() { return getToken(FEEL_1_1Parser.AND, 0); }
		public ComparisonExpressionContext comparisonExpression() {
			return getRuleContext(ComparisonExpressionContext.class,0);
		}
		public CondAndContext(ConditionalAndExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitCondAnd(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConditionalAndExpressionContext conditionalAndExpression() throws RecognitionException {
		return conditionalAndExpression(0);
	}

	private ConditionalAndExpressionContext conditionalAndExpression(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ConditionalAndExpressionContext _localctx = new ConditionalAndExpressionContext(_ctx, _parentState);
		ConditionalAndExpressionContext _prevctx = _localctx;
		int _startState = 56;
		enterRecursionRule(_localctx, 56, RULE_conditionalAndExpression, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			_localctx = new CondAndCompContext(_localctx);
			_ctx = _localctx;
			_prevctx = _localctx;

			setState(351);
			comparisonExpression(0);
			}
			_ctx.stop = _input.LT(-1);
			setState(358);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,23,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new CondAndContext(new ConditionalAndExpressionContext(_parentctx, _parentState));
					((CondAndContext)_localctx).left = _prevctx;
					pushNewRecursionContext(_localctx, _startState, RULE_conditionalAndExpression);
					setState(353);
					if (!(precpred(_ctx, 1))) throw new FailedPredicateException(this, "precpred(_ctx, 1)");
					setState(354);
					((CondAndContext)_localctx).op = match(AND);
					setState(355);
					((CondAndContext)_localctx).right = comparisonExpression(0);
					}
					} 
				}
				setState(360);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,23,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class ComparisonExpressionContext extends ParserRuleContext {
		public ComparisonExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_comparisonExpression; }
	 
		public ComparisonExpressionContext() { }
		public void copyFrom(ComparisonExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class CompExpressionContext extends ComparisonExpressionContext {
		public ComparisonExpressionContext left;
		public Token op;
		public RelationalExpressionContext right;
		public ComparisonExpressionContext comparisonExpression() {
			return getRuleContext(ComparisonExpressionContext.class,0);
		}
		public RelationalExpressionContext relationalExpression() {
			return getRuleContext(RelationalExpressionContext.class,0);
		}
		public TerminalNode LT() { return getToken(FEEL_1_1Parser.LT, 0); }
		public TerminalNode GT() { return getToken(FEEL_1_1Parser.GT, 0); }
		public TerminalNode LE() { return getToken(FEEL_1_1Parser.LE, 0); }
		public TerminalNode GE() { return getToken(FEEL_1_1Parser.GE, 0); }
		public TerminalNode EQUAL() { return getToken(FEEL_1_1Parser.EQUAL, 0); }
		public TerminalNode NOTEQUAL() { return getToken(FEEL_1_1Parser.NOTEQUAL, 0); }
		public CompExpressionContext(ComparisonExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitCompExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class CompExpressionRelContext extends ComparisonExpressionContext {
		public RelationalExpressionContext relationalExpression() {
			return getRuleContext(RelationalExpressionContext.class,0);
		}
		public CompExpressionRelContext(ComparisonExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitCompExpressionRel(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ComparisonExpressionContext comparisonExpression() throws RecognitionException {
		return comparisonExpression(0);
	}

	private ComparisonExpressionContext comparisonExpression(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ComparisonExpressionContext _localctx = new ComparisonExpressionContext(_ctx, _parentState);
		ComparisonExpressionContext _prevctx = _localctx;
		int _startState = 58;
		enterRecursionRule(_localctx, 58, RULE_comparisonExpression, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			_localctx = new CompExpressionRelContext(_localctx);
			_ctx = _localctx;
			_prevctx = _localctx;

			setState(362);
			relationalExpression(0);
			}
			_ctx.stop = _input.LT(-1);
			setState(369);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,24,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new CompExpressionContext(new ComparisonExpressionContext(_parentctx, _parentState));
					((CompExpressionContext)_localctx).left = _prevctx;
					pushNewRecursionContext(_localctx, _startState, RULE_comparisonExpression);
					setState(364);
					if (!(precpred(_ctx, 1))) throw new FailedPredicateException(this, "precpred(_ctx, 1)");
					setState(365);
					((CompExpressionContext)_localctx).op = _input.LT(1);
					_la = _input.LA(1);
					if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << EQUAL) | (1L << GT) | (1L << LT) | (1L << LE) | (1L << GE) | (1L << NOTEQUAL))) != 0)) ) {
						((CompExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					setState(366);
					((CompExpressionContext)_localctx).right = relationalExpression(0);
					}
					} 
				}
				setState(371);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,24,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class RelationalExpressionContext extends ParserRuleContext {
		public RelationalExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_relationalExpression; }
	 
		public RelationalExpressionContext() { }
		public void copyFrom(RelationalExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class RelExpressionBetweenContext extends RelationalExpressionContext {
		public RelationalExpressionContext val;
		public AdditiveExpressionContext start;
		public AdditiveExpressionContext end;
		public TerminalNode BETWEEN() { return getToken(FEEL_1_1Parser.BETWEEN, 0); }
		public TerminalNode AND() { return getToken(FEEL_1_1Parser.AND, 0); }
		public RelationalExpressionContext relationalExpression() {
			return getRuleContext(RelationalExpressionContext.class,0);
		}
		public List<AdditiveExpressionContext> additiveExpression() {
			return getRuleContexts(AdditiveExpressionContext.class);
		}
		public AdditiveExpressionContext additiveExpression(int i) {
			return getRuleContext(AdditiveExpressionContext.class,i);
		}
		public RelExpressionBetweenContext(RelationalExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitRelExpressionBetween(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class RelExpressionValueContext extends RelationalExpressionContext {
		public RelationalExpressionContext val;
		public TerminalNode IN() { return getToken(FEEL_1_1Parser.IN, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public RelationalExpressionContext relationalExpression() {
			return getRuleContext(RelationalExpressionContext.class,0);
		}
		public RelExpressionValueContext(RelationalExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitRelExpressionValue(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class RelExpressionTestListContext extends RelationalExpressionContext {
		public RelationalExpressionContext val;
		public TerminalNode IN() { return getToken(FEEL_1_1Parser.IN, 0); }
		public TerminalNode LPAREN() { return getToken(FEEL_1_1Parser.LPAREN, 0); }
		public PositiveUnaryTestsContext positiveUnaryTests() {
			return getRuleContext(PositiveUnaryTestsContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(FEEL_1_1Parser.RPAREN, 0); }
		public RelationalExpressionContext relationalExpression() {
			return getRuleContext(RelationalExpressionContext.class,0);
		}
		public RelExpressionTestListContext(RelationalExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitRelExpressionTestList(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class RelExpressionAddContext extends RelationalExpressionContext {
		public AdditiveExpressionContext additiveExpression() {
			return getRuleContext(AdditiveExpressionContext.class,0);
		}
		public RelExpressionAddContext(RelationalExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitRelExpressionAdd(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class RelExpressionInstanceOfContext extends RelationalExpressionContext {
		public RelationalExpressionContext val;
		public TerminalNode INSTANCE() { return getToken(FEEL_1_1Parser.INSTANCE, 0); }
		public TerminalNode OF() { return getToken(FEEL_1_1Parser.OF, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public RelationalExpressionContext relationalExpression() {
			return getRuleContext(RelationalExpressionContext.class,0);
		}
		public RelExpressionInstanceOfContext(RelationalExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitRelExpressionInstanceOf(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RelationalExpressionContext relationalExpression() throws RecognitionException {
		return relationalExpression(0);
	}

	private RelationalExpressionContext relationalExpression(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		RelationalExpressionContext _localctx = new RelationalExpressionContext(_ctx, _parentState);
		RelationalExpressionContext _prevctx = _localctx;
		int _startState = 60;
		enterRecursionRule(_localctx, 60, RULE_relationalExpression, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			_localctx = new RelExpressionAddContext(_localctx);
			_ctx = _localctx;
			_prevctx = _localctx;

			setState(373);
			additiveExpression(0);
			}
			_ctx.stop = _input.LT(-1);
			setState(396);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,26,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(394);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,25,_ctx) ) {
					case 1:
						{
						_localctx = new RelExpressionBetweenContext(new RelationalExpressionContext(_parentctx, _parentState));
						((RelExpressionBetweenContext)_localctx).val = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_relationalExpression);
						setState(375);
						if (!(precpred(_ctx, 4))) throw new FailedPredicateException(this, "precpred(_ctx, 4)");
						setState(376);
						match(BETWEEN);
						setState(377);
						((RelExpressionBetweenContext)_localctx).start = additiveExpression(0);
						setState(378);
						match(AND);
						setState(379);
						((RelExpressionBetweenContext)_localctx).end = additiveExpression(0);
						}
						break;
					case 2:
						{
						_localctx = new RelExpressionTestListContext(new RelationalExpressionContext(_parentctx, _parentState));
						((RelExpressionTestListContext)_localctx).val = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_relationalExpression);
						setState(381);
						if (!(precpred(_ctx, 3))) throw new FailedPredicateException(this, "precpred(_ctx, 3)");
						setState(382);
						match(IN);
						setState(383);
						match(LPAREN);
						setState(384);
						positiveUnaryTests();
						setState(385);
						match(RPAREN);
						}
						break;
					case 3:
						{
						_localctx = new RelExpressionValueContext(new RelationalExpressionContext(_parentctx, _parentState));
						((RelExpressionValueContext)_localctx).val = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_relationalExpression);
						setState(387);
						if (!(precpred(_ctx, 2))) throw new FailedPredicateException(this, "precpred(_ctx, 2)");
						setState(388);
						match(IN);
						setState(389);
						expression();
						}
						break;
					case 4:
						{
						_localctx = new RelExpressionInstanceOfContext(new RelationalExpressionContext(_parentctx, _parentState));
						((RelExpressionInstanceOfContext)_localctx).val = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_relationalExpression);
						setState(390);
						if (!(precpred(_ctx, 1))) throw new FailedPredicateException(this, "precpred(_ctx, 1)");
						setState(391);
						match(INSTANCE);
						setState(392);
						match(OF);
						setState(393);
						type();
						}
						break;
					}
					} 
				}
				setState(398);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,26,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class ExpressionListContext extends ParserRuleContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(FEEL_1_1Parser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(FEEL_1_1Parser.COMMA, i);
		}
		public ExpressionListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expressionList; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitExpressionList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExpressionListContext expressionList() throws RecognitionException {
		ExpressionListContext _localctx = new ExpressionListContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_expressionList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(399);
			expression();
			setState(404);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(400);
				match(COMMA);
				setState(401);
				expression();
				}
				}
				setState(406);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AdditiveExpressionContext extends ParserRuleContext {
		public AdditiveExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_additiveExpression; }
	 
		public AdditiveExpressionContext() { }
		public void copyFrom(AdditiveExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class AddExpressionMultContext extends AdditiveExpressionContext {
		public MultiplicativeExpressionContext multiplicativeExpression() {
			return getRuleContext(MultiplicativeExpressionContext.class,0);
		}
		public AddExpressionMultContext(AdditiveExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitAddExpressionMult(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class AddExpressionContext extends AdditiveExpressionContext {
		public Token op;
		public AdditiveExpressionContext additiveExpression() {
			return getRuleContext(AdditiveExpressionContext.class,0);
		}
		public MultiplicativeExpressionContext multiplicativeExpression() {
			return getRuleContext(MultiplicativeExpressionContext.class,0);
		}
		public TerminalNode ADD() { return getToken(FEEL_1_1Parser.ADD, 0); }
		public TerminalNode SUB() { return getToken(FEEL_1_1Parser.SUB, 0); }
		public AddExpressionContext(AdditiveExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitAddExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AdditiveExpressionContext additiveExpression() throws RecognitionException {
		return additiveExpression(0);
	}

	private AdditiveExpressionContext additiveExpression(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		AdditiveExpressionContext _localctx = new AdditiveExpressionContext(_ctx, _parentState);
		AdditiveExpressionContext _prevctx = _localctx;
		int _startState = 64;
		enterRecursionRule(_localctx, 64, RULE_additiveExpression, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			_localctx = new AddExpressionMultContext(_localctx);
			_ctx = _localctx;
			_prevctx = _localctx;

			setState(408);
			multiplicativeExpression(0);
			}
			_ctx.stop = _input.LT(-1);
			setState(418);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,29,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(416);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,28,_ctx) ) {
					case 1:
						{
						_localctx = new AddExpressionContext(new AdditiveExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_additiveExpression);
						setState(410);
						if (!(precpred(_ctx, 2))) throw new FailedPredicateException(this, "precpred(_ctx, 2)");
						setState(411);
						((AddExpressionContext)_localctx).op = match(ADD);
						setState(412);
						multiplicativeExpression(0);
						}
						break;
					case 2:
						{
						_localctx = new AddExpressionContext(new AdditiveExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_additiveExpression);
						setState(413);
						if (!(precpred(_ctx, 1))) throw new FailedPredicateException(this, "precpred(_ctx, 1)");
						setState(414);
						((AddExpressionContext)_localctx).op = match(SUB);
						setState(415);
						multiplicativeExpression(0);
						}
						break;
					}
					} 
				}
				setState(420);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,29,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class MultiplicativeExpressionContext extends ParserRuleContext {
		public MultiplicativeExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_multiplicativeExpression; }
	 
		public MultiplicativeExpressionContext() { }
		public void copyFrom(MultiplicativeExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class MultExpressionPowContext extends MultiplicativeExpressionContext {
		public PowerExpressionContext powerExpression() {
			return getRuleContext(PowerExpressionContext.class,0);
		}
		public MultExpressionPowContext(MultiplicativeExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitMultExpressionPow(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class MultExpressionContext extends MultiplicativeExpressionContext {
		public Token op;
		public MultiplicativeExpressionContext multiplicativeExpression() {
			return getRuleContext(MultiplicativeExpressionContext.class,0);
		}
		public PowerExpressionContext powerExpression() {
			return getRuleContext(PowerExpressionContext.class,0);
		}
		public TerminalNode MUL() { return getToken(FEEL_1_1Parser.MUL, 0); }
		public TerminalNode DIV() { return getToken(FEEL_1_1Parser.DIV, 0); }
		public MultExpressionContext(MultiplicativeExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitMultExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MultiplicativeExpressionContext multiplicativeExpression() throws RecognitionException {
		return multiplicativeExpression(0);
	}

	private MultiplicativeExpressionContext multiplicativeExpression(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		MultiplicativeExpressionContext _localctx = new MultiplicativeExpressionContext(_ctx, _parentState);
		MultiplicativeExpressionContext _prevctx = _localctx;
		int _startState = 66;
		enterRecursionRule(_localctx, 66, RULE_multiplicativeExpression, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			_localctx = new MultExpressionPowContext(_localctx);
			_ctx = _localctx;
			_prevctx = _localctx;

			setState(422);
			powerExpression(0);
			}
			_ctx.stop = _input.LT(-1);
			setState(429);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,30,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new MultExpressionContext(new MultiplicativeExpressionContext(_parentctx, _parentState));
					pushNewRecursionContext(_localctx, _startState, RULE_multiplicativeExpression);
					setState(424);
					if (!(precpred(_ctx, 1))) throw new FailedPredicateException(this, "precpred(_ctx, 1)");
					setState(425);
					((MultExpressionContext)_localctx).op = _input.LT(1);
					_la = _input.LA(1);
					if ( !(_la==MUL || _la==DIV) ) {
						((MultExpressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					setState(426);
					powerExpression(0);
					}
					} 
				}
				setState(431);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,30,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class PowerExpressionContext extends ParserRuleContext {
		public PowerExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_powerExpression; }
	 
		public PowerExpressionContext() { }
		public void copyFrom(PowerExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class PowExpressionUnaryContext extends PowerExpressionContext {
		public FilterPathExpressionContext filterPathExpression() {
			return getRuleContext(FilterPathExpressionContext.class,0);
		}
		public PowExpressionUnaryContext(PowerExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitPowExpressionUnary(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PowExpressionContext extends PowerExpressionContext {
		public Token op;
		public PowerExpressionContext powerExpression() {
			return getRuleContext(PowerExpressionContext.class,0);
		}
		public FilterPathExpressionContext filterPathExpression() {
			return getRuleContext(FilterPathExpressionContext.class,0);
		}
		public TerminalNode POW() { return getToken(FEEL_1_1Parser.POW, 0); }
		public PowExpressionContext(PowerExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitPowExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PowerExpressionContext powerExpression() throws RecognitionException {
		return powerExpression(0);
	}

	private PowerExpressionContext powerExpression(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		PowerExpressionContext _localctx = new PowerExpressionContext(_ctx, _parentState);
		PowerExpressionContext _prevctx = _localctx;
		int _startState = 68;
		enterRecursionRule(_localctx, 68, RULE_powerExpression, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			_localctx = new PowExpressionUnaryContext(_localctx);
			_ctx = _localctx;
			_prevctx = _localctx;

			setState(433);
			filterPathExpression(0);
			}
			_ctx.stop = _input.LT(-1);
			setState(440);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,31,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new PowExpressionContext(new PowerExpressionContext(_parentctx, _parentState));
					pushNewRecursionContext(_localctx, _startState, RULE_powerExpression);
					setState(435);
					if (!(precpred(_ctx, 1))) throw new FailedPredicateException(this, "precpred(_ctx, 1)");
					setState(436);
					((PowExpressionContext)_localctx).op = match(POW);
					setState(437);
					filterPathExpression(0);
					}
					} 
				}
				setState(442);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,31,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class FilterPathExpressionContext extends ParserRuleContext {
		public ExpressionContext filter;
		public UnaryExpressionContext unaryExpression() {
			return getRuleContext(UnaryExpressionContext.class,0);
		}
		public FilterPathExpressionContext filterPathExpression() {
			return getRuleContext(FilterPathExpressionContext.class,0);
		}
		public TerminalNode LBRACK() { return getToken(FEEL_1_1Parser.LBRACK, 0); }
		public TerminalNode RBRACK() { return getToken(FEEL_1_1Parser.RBRACK, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode DOT() { return getToken(FEEL_1_1Parser.DOT, 0); }
		public QualifiedNameContext qualifiedName() {
			return getRuleContext(QualifiedNameContext.class,0);
		}
		public FilterPathExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_filterPathExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitFilterPathExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FilterPathExpressionContext filterPathExpression() throws RecognitionException {
		return filterPathExpression(0);
	}

	private FilterPathExpressionContext filterPathExpression(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		FilterPathExpressionContext _localctx = new FilterPathExpressionContext(_ctx, _parentState);
		FilterPathExpressionContext _prevctx = _localctx;
		int _startState = 70;
		enterRecursionRule(_localctx, 70, RULE_filterPathExpression, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			setState(444);
			unaryExpression(0);
			}
			_ctx.stop = _input.LT(-1);
			setState(461);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,33,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(459);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,32,_ctx) ) {
					case 1:
						{
						_localctx = new FilterPathExpressionContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_filterPathExpression);
						setState(446);
						if (!(precpred(_ctx, 2))) throw new FailedPredicateException(this, "precpred(_ctx, 2)");
						setState(447);
						match(LBRACK);
						helper.enableDynamicResolution();
						setState(449);
						((FilterPathExpressionContext)_localctx).filter = expression();
						helper.disableDynamicResolution();
						setState(451);
						match(RBRACK);
						}
						break;
					case 2:
						{
						_localctx = new FilterPathExpressionContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_filterPathExpression);
						setState(453);
						if (!(precpred(_ctx, 1))) throw new FailedPredicateException(this, "precpred(_ctx, 1)");
						setState(454);
						match(DOT);
						helper.enableDynamicResolution();
						setState(456);
						qualifiedName();
						helper.disableDynamicResolution();
						}
						break;
					}
					} 
				}
				setState(463);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,33,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class UnaryExpressionContext extends ParserRuleContext {
		public UnaryExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_unaryExpression; }
	 
		public UnaryExpressionContext() { }
		public void copyFrom(UnaryExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class SignedUnaryExpressionPlusContext extends UnaryExpressionContext {
		public TerminalNode ADD() { return getToken(FEEL_1_1Parser.ADD, 0); }
		public UnaryExpressionNotPlusMinusContext unaryExpressionNotPlusMinus() {
			return getRuleContext(UnaryExpressionNotPlusMinusContext.class,0);
		}
		public SignedUnaryExpressionPlusContext(UnaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitSignedUnaryExpressionPlus(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class SignedUnaryExpressionMinusContext extends UnaryExpressionContext {
		public TerminalNode SUB() { return getToken(FEEL_1_1Parser.SUB, 0); }
		public UnaryExpressionContext unaryExpression() {
			return getRuleContext(UnaryExpressionContext.class,0);
		}
		public SignedUnaryExpressionMinusContext(UnaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitSignedUnaryExpressionMinus(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class FnInvocationContext extends UnaryExpressionContext {
		public UnaryExpressionContext unaryExpression() {
			return getRuleContext(UnaryExpressionContext.class,0);
		}
		public ParametersContext parameters() {
			return getRuleContext(ParametersContext.class,0);
		}
		public FnInvocationContext(UnaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitFnInvocation(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class NonSignedUnaryExpressionContext extends UnaryExpressionContext {
		public UnaryExpressionNotPlusMinusContext unaryExpressionNotPlusMinus() {
			return getRuleContext(UnaryExpressionNotPlusMinusContext.class,0);
		}
		public NonSignedUnaryExpressionContext(UnaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitNonSignedUnaryExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final UnaryExpressionContext unaryExpression() throws RecognitionException {
		return unaryExpression(0);
	}

	private UnaryExpressionContext unaryExpression(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		UnaryExpressionContext _localctx = new UnaryExpressionContext(_ctx, _parentState);
		UnaryExpressionContext _prevctx = _localctx;
		int _startState = 72;
		enterRecursionRule(_localctx, 72, RULE_unaryExpression, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(470);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SUB:
				{
				_localctx = new SignedUnaryExpressionMinusContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(465);
				match(SUB);
				setState(466);
				unaryExpression(3);
				}
				break;
			case BooleanLiteral:
			case FOR:
			case IF:
			case SOME:
			case EVERY:
			case NULL:
			case IntegerLiteral:
			case FloatingPointLiteral:
			case StringLiteral:
			case LPAREN:
			case LBRACE:
			case LBRACK:
			case RBRACK:
			case EQUAL:
			case GT:
			case LT:
			case LE:
			case GE:
			case NOTEQUAL:
			case NOT:
			case AT:
			case Identifier:
				{
				_localctx = new NonSignedUnaryExpressionContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(467);
				unaryExpressionNotPlusMinus();
				}
				break;
			case ADD:
				{
				_localctx = new SignedUnaryExpressionPlusContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(468);
				match(ADD);
				setState(469);
				unaryExpressionNotPlusMinus();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			_ctx.stop = _input.LT(-1);
			setState(476);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,35,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new FnInvocationContext(new UnaryExpressionContext(_parentctx, _parentState));
					pushNewRecursionContext(_localctx, _startState, RULE_unaryExpression);
					setState(472);
					if (!(precpred(_ctx, 4))) throw new FailedPredicateException(this, "precpred(_ctx, 4)");
					setState(473);
					parameters();
					}
					} 
				}
				setState(478);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,35,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class UnaryExpressionNotPlusMinusContext extends ParserRuleContext {
		public UnaryExpressionNotPlusMinusContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_unaryExpressionNotPlusMinus; }
	 
		public UnaryExpressionNotPlusMinusContext() { }
		public void copyFrom(UnaryExpressionNotPlusMinusContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class UenpmPrimaryContext extends UnaryExpressionNotPlusMinusContext {
		public PrimaryContext primary() {
			return getRuleContext(PrimaryContext.class,0);
		}
		public TerminalNode DOT() { return getToken(FEEL_1_1Parser.DOT, 0); }
		public QualifiedNameContext qualifiedName() {
			return getRuleContext(QualifiedNameContext.class,0);
		}
		public ParametersContext parameters() {
			return getRuleContext(ParametersContext.class,0);
		}
		public UenpmPrimaryContext(UnaryExpressionNotPlusMinusContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitUenpmPrimary(this);
			else return visitor.visitChildren(this);
		}
	}

	public final UnaryExpressionNotPlusMinusContext unaryExpressionNotPlusMinus() throws RecognitionException {
		UnaryExpressionNotPlusMinusContext _localctx = new UnaryExpressionNotPlusMinusContext(_ctx, getState());
		enterRule(_localctx, 74, RULE_unaryExpressionNotPlusMinus);
		try {
			_localctx = new UenpmPrimaryContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(479);
			primary();
			setState(488);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,37,_ctx) ) {
			case 1:
				{
				setState(480);
				match(DOT);
				helper.recoverScope();helper.enableDynamicResolution();
				setState(482);
				qualifiedName();
				setState(484);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,36,_ctx) ) {
				case 1:
					{
					setState(483);
					parameters();
					}
					break;
				}
				helper.disableDynamicResolution();helper.dismissScope();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PrimaryContext extends ParserRuleContext {
		public PrimaryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_primary; }
	 
		public PrimaryContext() { }
		public void copyFrom(PrimaryContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class PrimaryQuantifiedExpressionContext extends PrimaryContext {
		public QuantifiedExpressionContext quantifiedExpression() {
			return getRuleContext(QuantifiedExpressionContext.class,0);
		}
		public PrimaryQuantifiedExpressionContext(PrimaryContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitPrimaryQuantifiedExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PrimaryContextContext extends PrimaryContext {
		public ContextContext context() {
			return getRuleContext(ContextContext.class,0);
		}
		public PrimaryContextContext(PrimaryContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitPrimaryContext(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PrimaryIfExpressionContext extends PrimaryContext {
		public IfExpressionContext ifExpression() {
			return getRuleContext(IfExpressionContext.class,0);
		}
		public PrimaryIfExpressionContext(PrimaryContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitPrimaryIfExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PrimaryIntervalContext extends PrimaryContext {
		public IntervalContext interval() {
			return getRuleContext(IntervalContext.class,0);
		}
		public PrimaryIntervalContext(PrimaryContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitPrimaryInterval(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PrimaryListContext extends PrimaryContext {
		public ListContext list() {
			return getRuleContext(ListContext.class,0);
		}
		public PrimaryListContext(PrimaryContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitPrimaryList(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PrimaryUnaryTestContext extends PrimaryContext {
		public SimplePositiveUnaryTestContext simplePositiveUnaryTest() {
			return getRuleContext(SimplePositiveUnaryTestContext.class,0);
		}
		public PrimaryUnaryTestContext(PrimaryContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitPrimaryUnaryTest(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PrimaryNameContext extends PrimaryContext {
		public QualifiedNameContext qualifiedName() {
			return getRuleContext(QualifiedNameContext.class,0);
		}
		public PrimaryNameContext(PrimaryContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitPrimaryName(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PrimaryForExpressionContext extends PrimaryContext {
		public ForExpressionContext forExpression() {
			return getRuleContext(ForExpressionContext.class,0);
		}
		public PrimaryForExpressionContext(PrimaryContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitPrimaryForExpression(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PrimaryParensContext extends PrimaryContext {
		public TerminalNode LPAREN() { return getToken(FEEL_1_1Parser.LPAREN, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(FEEL_1_1Parser.RPAREN, 0); }
		public PrimaryParensContext(PrimaryContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitPrimaryParens(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PrimaryLiteralContext extends PrimaryContext {
		public LiteralContext literal() {
			return getRuleContext(LiteralContext.class,0);
		}
		public PrimaryLiteralContext(PrimaryContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitPrimaryLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PrimaryContext primary() throws RecognitionException {
		PrimaryContext _localctx = new PrimaryContext(_ctx, getState());
		enterRule(_localctx, 76, RULE_primary);
		try {
			setState(503);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,38,_ctx) ) {
			case 1:
				_localctx = new PrimaryLiteralContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(490);
				literal();
				}
				break;
			case 2:
				_localctx = new PrimaryForExpressionContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(491);
				forExpression();
				}
				break;
			case 3:
				_localctx = new PrimaryQuantifiedExpressionContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(492);
				quantifiedExpression();
				}
				break;
			case 4:
				_localctx = new PrimaryIfExpressionContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(493);
				ifExpression();
				}
				break;
			case 5:
				_localctx = new PrimaryIntervalContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(494);
				interval();
				}
				break;
			case 6:
				_localctx = new PrimaryListContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(495);
				list();
				}
				break;
			case 7:
				_localctx = new PrimaryContextContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(496);
				context();
				}
				break;
			case 8:
				_localctx = new PrimaryParensContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(497);
				match(LPAREN);
				setState(498);
				expression();
				setState(499);
				match(RPAREN);
				}
				break;
			case 9:
				_localctx = new PrimaryUnaryTestContext(_localctx);
				enterOuterAlt(_localctx, 9);
				{
				setState(501);
				simplePositiveUnaryTest();
				}
				break;
			case 10:
				_localctx = new PrimaryNameContext(_localctx);
				enterOuterAlt(_localctx, 10);
				{
				setState(502);
				qualifiedName();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LiteralContext extends ParserRuleContext {
		public LiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_literal; }
	 
		public LiteralContext() { }
		public void copyFrom(LiteralContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class NullLiteralContext extends LiteralContext {
		public TerminalNode NULL() { return getToken(FEEL_1_1Parser.NULL, 0); }
		public NullLiteralContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitNullLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class StringLiteralContext extends LiteralContext {
		public TerminalNode StringLiteral() { return getToken(FEEL_1_1Parser.StringLiteral, 0); }
		public StringLiteralContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitStringLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class AtLiteralLabelContext extends LiteralContext {
		public AtLiteralContext atLiteral() {
			return getRuleContext(AtLiteralContext.class,0);
		}
		public AtLiteralLabelContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitAtLiteralLabel(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BoolLiteralContext extends LiteralContext {
		public TerminalNode BooleanLiteral() { return getToken(FEEL_1_1Parser.BooleanLiteral, 0); }
		public BoolLiteralContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitBoolLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class NumberLiteralContext extends LiteralContext {
		public TerminalNode IntegerLiteral() { return getToken(FEEL_1_1Parser.IntegerLiteral, 0); }
		public TerminalNode FloatingPointLiteral() { return getToken(FEEL_1_1Parser.FloatingPointLiteral, 0); }
		public NumberLiteralContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitNumberLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LiteralContext literal() throws RecognitionException {
		LiteralContext _localctx = new LiteralContext(_ctx, getState());
		enterRule(_localctx, 78, RULE_literal);
		try {
			setState(511);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case IntegerLiteral:
				_localctx = new NumberLiteralContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(505);
				match(IntegerLiteral);
				}
				break;
			case FloatingPointLiteral:
				_localctx = new NumberLiteralContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(506);
				match(FloatingPointLiteral);
				}
				break;
			case BooleanLiteral:
				_localctx = new BoolLiteralContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(507);
				match(BooleanLiteral);
				}
				break;
			case AT:
				_localctx = new AtLiteralLabelContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(508);
				atLiteral();
				}
				break;
			case StringLiteral:
				_localctx = new StringLiteralContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(509);
				match(StringLiteral);
				}
				break;
			case NULL:
				_localctx = new NullLiteralContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(510);
				match(NULL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AtLiteralContext extends ParserRuleContext {
		public TerminalNode AT() { return getToken(FEEL_1_1Parser.AT, 0); }
		public AtLiteralValueContext atLiteralValue() {
			return getRuleContext(AtLiteralValueContext.class,0);
		}
		public AtLiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_atLiteral; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitAtLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AtLiteralContext atLiteral() throws RecognitionException {
		AtLiteralContext _localctx = new AtLiteralContext(_ctx, getState());
		enterRule(_localctx, 80, RULE_atLiteral);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(513);
			match(AT);
			setState(514);
			atLiteralValue();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AtLiteralValueContext extends ParserRuleContext {
		public TerminalNode StringLiteral() { return getToken(FEEL_1_1Parser.StringLiteral, 0); }
		public AtLiteralValueContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_atLiteralValue; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitAtLiteralValue(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AtLiteralValueContext atLiteralValue() throws RecognitionException {
		AtLiteralValueContext _localctx = new AtLiteralValueContext(_ctx, getState());
		enterRule(_localctx, 82, RULE_atLiteralValue);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(516);
			match(StringLiteral);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SimplePositiveUnaryTestContext extends ParserRuleContext {
		public SimplePositiveUnaryTestContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simplePositiveUnaryTest; }
	 
		public SimplePositiveUnaryTestContext() { }
		public void copyFrom(SimplePositiveUnaryTestContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class PositiveUnaryTestIntervalContext extends SimplePositiveUnaryTestContext {
		public IntervalContext interval() {
			return getRuleContext(IntervalContext.class,0);
		}
		public PositiveUnaryTestIntervalContext(SimplePositiveUnaryTestContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitPositiveUnaryTestInterval(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PositiveUnaryTestIneqContext extends SimplePositiveUnaryTestContext {
		public Token op;
		public EndpointContext endpoint() {
			return getRuleContext(EndpointContext.class,0);
		}
		public TerminalNode EQUAL() { return getToken(FEEL_1_1Parser.EQUAL, 0); }
		public TerminalNode NOTEQUAL() { return getToken(FEEL_1_1Parser.NOTEQUAL, 0); }
		public PositiveUnaryTestIneqContext(SimplePositiveUnaryTestContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitPositiveUnaryTestIneq(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PositiveUnaryTestIneqIntervalContext extends SimplePositiveUnaryTestContext {
		public Token op;
		public EndpointContext endpoint() {
			return getRuleContext(EndpointContext.class,0);
		}
		public TerminalNode LT() { return getToken(FEEL_1_1Parser.LT, 0); }
		public TerminalNode GT() { return getToken(FEEL_1_1Parser.GT, 0); }
		public TerminalNode LE() { return getToken(FEEL_1_1Parser.LE, 0); }
		public TerminalNode GE() { return getToken(FEEL_1_1Parser.GE, 0); }
		public PositiveUnaryTestIneqIntervalContext(SimplePositiveUnaryTestContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitPositiveUnaryTestIneqInterval(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SimplePositiveUnaryTestContext simplePositiveUnaryTest() throws RecognitionException {
		SimplePositiveUnaryTestContext _localctx = new SimplePositiveUnaryTestContext(_ctx, getState());
		enterRule(_localctx, 84, RULE_simplePositiveUnaryTest);
		try {
			setState(549);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LT:
				_localctx = new PositiveUnaryTestIneqIntervalContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(518);
				((PositiveUnaryTestIneqIntervalContext)_localctx).op = match(LT);
				helper.enableDynamicResolution();
				setState(520);
				endpoint();
				helper.disableDynamicResolution();
				}
				break;
			case GT:
				_localctx = new PositiveUnaryTestIneqIntervalContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(523);
				((PositiveUnaryTestIneqIntervalContext)_localctx).op = match(GT);
				helper.enableDynamicResolution();
				setState(525);
				endpoint();
				helper.disableDynamicResolution();
				}
				break;
			case LE:
				_localctx = new PositiveUnaryTestIneqIntervalContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(528);
				((PositiveUnaryTestIneqIntervalContext)_localctx).op = match(LE);
				helper.enableDynamicResolution();
				setState(530);
				endpoint();
				helper.disableDynamicResolution();
				}
				break;
			case GE:
				_localctx = new PositiveUnaryTestIneqIntervalContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(533);
				((PositiveUnaryTestIneqIntervalContext)_localctx).op = match(GE);
				helper.enableDynamicResolution();
				setState(535);
				endpoint();
				helper.disableDynamicResolution();
				}
				break;
			case EQUAL:
				_localctx = new PositiveUnaryTestIneqContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(538);
				((PositiveUnaryTestIneqContext)_localctx).op = match(EQUAL);
				helper.enableDynamicResolution();
				setState(540);
				endpoint();
				helper.disableDynamicResolution();
				}
				break;
			case NOTEQUAL:
				_localctx = new PositiveUnaryTestIneqContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(543);
				((PositiveUnaryTestIneqContext)_localctx).op = match(NOTEQUAL);
				helper.enableDynamicResolution();
				setState(545);
				endpoint();
				helper.disableDynamicResolution();
				}
				break;
			case LPAREN:
			case LBRACK:
			case RBRACK:
				_localctx = new PositiveUnaryTestIntervalContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(548);
				interval();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SimplePositiveUnaryTestsContext extends ParserRuleContext {
		public List<SimplePositiveUnaryTestContext> simplePositiveUnaryTest() {
			return getRuleContexts(SimplePositiveUnaryTestContext.class);
		}
		public SimplePositiveUnaryTestContext simplePositiveUnaryTest(int i) {
			return getRuleContext(SimplePositiveUnaryTestContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(FEEL_1_1Parser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(FEEL_1_1Parser.COMMA, i);
		}
		public SimplePositiveUnaryTestsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simplePositiveUnaryTests; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitSimplePositiveUnaryTests(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SimplePositiveUnaryTestsContext simplePositiveUnaryTests() throws RecognitionException {
		SimplePositiveUnaryTestsContext _localctx = new SimplePositiveUnaryTestsContext(_ctx, getState());
		enterRule(_localctx, 86, RULE_simplePositiveUnaryTests);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(551);
			simplePositiveUnaryTest();
			setState(556);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(552);
				match(COMMA);
				setState(553);
				simplePositiveUnaryTest();
				}
				}
				setState(558);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SimpleUnaryTestsContext extends ParserRuleContext {
		public SimpleUnaryTestsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simpleUnaryTests; }
	 
		public SimpleUnaryTestsContext() { }
		public void copyFrom(SimpleUnaryTestsContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class PositiveUnaryTestDashContext extends SimpleUnaryTestsContext {
		public TerminalNode SUB() { return getToken(FEEL_1_1Parser.SUB, 0); }
		public PositiveUnaryTestDashContext(SimpleUnaryTestsContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitPositiveUnaryTestDash(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PositiveSimplePositiveUnaryTestsContext extends SimpleUnaryTestsContext {
		public SimplePositiveUnaryTestsContext simplePositiveUnaryTests() {
			return getRuleContext(SimplePositiveUnaryTestsContext.class,0);
		}
		public PositiveSimplePositiveUnaryTestsContext(SimpleUnaryTestsContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitPositiveSimplePositiveUnaryTests(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class NegatedSimplePositiveUnaryTestsContext extends SimpleUnaryTestsContext {
		public TerminalNode NOT() { return getToken(FEEL_1_1Parser.NOT, 0); }
		public TerminalNode LPAREN() { return getToken(FEEL_1_1Parser.LPAREN, 0); }
		public SimplePositiveUnaryTestsContext simplePositiveUnaryTests() {
			return getRuleContext(SimplePositiveUnaryTestsContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(FEEL_1_1Parser.RPAREN, 0); }
		public NegatedSimplePositiveUnaryTestsContext(SimpleUnaryTestsContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitNegatedSimplePositiveUnaryTests(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SimpleUnaryTestsContext simpleUnaryTests() throws RecognitionException {
		SimpleUnaryTestsContext _localctx = new SimpleUnaryTestsContext(_ctx, getState());
		enterRule(_localctx, 88, RULE_simpleUnaryTests);
		try {
			setState(566);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LPAREN:
			case LBRACK:
			case RBRACK:
			case EQUAL:
			case GT:
			case LT:
			case LE:
			case GE:
			case NOTEQUAL:
				_localctx = new PositiveSimplePositiveUnaryTestsContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(559);
				simplePositiveUnaryTests();
				}
				break;
			case NOT:
				_localctx = new NegatedSimplePositiveUnaryTestsContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(560);
				match(NOT);
				setState(561);
				match(LPAREN);
				setState(562);
				simplePositiveUnaryTests();
				setState(563);
				match(RPAREN);
				}
				break;
			case SUB:
				_localctx = new PositiveUnaryTestDashContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(565);
				match(SUB);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PositiveUnaryTestContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public PositiveUnaryTestContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_positiveUnaryTest; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitPositiveUnaryTest(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PositiveUnaryTestContext positiveUnaryTest() throws RecognitionException {
		PositiveUnaryTestContext _localctx = new PositiveUnaryTestContext(_ctx, getState());
		enterRule(_localctx, 90, RULE_positiveUnaryTest);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(568);
			expression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PositiveUnaryTestsContext extends ParserRuleContext {
		public List<PositiveUnaryTestContext> positiveUnaryTest() {
			return getRuleContexts(PositiveUnaryTestContext.class);
		}
		public PositiveUnaryTestContext positiveUnaryTest(int i) {
			return getRuleContext(PositiveUnaryTestContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(FEEL_1_1Parser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(FEEL_1_1Parser.COMMA, i);
		}
		public PositiveUnaryTestsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_positiveUnaryTests; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitPositiveUnaryTests(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PositiveUnaryTestsContext positiveUnaryTests() throws RecognitionException {
		PositiveUnaryTestsContext _localctx = new PositiveUnaryTestsContext(_ctx, getState());
		enterRule(_localctx, 92, RULE_positiveUnaryTests);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(570);
			positiveUnaryTest();
			setState(575);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(571);
				match(COMMA);
				setState(572);
				positiveUnaryTest();
				}
				}
				setState(577);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class UnaryTestsRootContext extends ParserRuleContext {
		public UnaryTestsContext unaryTests() {
			return getRuleContext(UnaryTestsContext.class,0);
		}
		public TerminalNode EOF() { return getToken(FEEL_1_1Parser.EOF, 0); }
		public UnaryTestsRootContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_unaryTestsRoot; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitUnaryTestsRoot(this);
			else return visitor.visitChildren(this);
		}
	}

	public final UnaryTestsRootContext unaryTestsRoot() throws RecognitionException {
		UnaryTestsRootContext _localctx = new UnaryTestsRootContext(_ctx, getState());
		enterRule(_localctx, 94, RULE_unaryTestsRoot);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(578);
			unaryTests();
			setState(579);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class UnaryTestsContext extends ParserRuleContext {
		public UnaryTestsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_unaryTests; }
	 
		public UnaryTestsContext() { }
		public void copyFrom(UnaryTestsContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class UnaryTests_emptyContext extends UnaryTestsContext {
		public TerminalNode SUB() { return getToken(FEEL_1_1Parser.SUB, 0); }
		public UnaryTests_emptyContext(UnaryTestsContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitUnaryTests_empty(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class UnaryTests_positiveContext extends UnaryTestsContext {
		public PositiveUnaryTestsContext positiveUnaryTests() {
			return getRuleContext(PositiveUnaryTestsContext.class,0);
		}
		public UnaryTests_positiveContext(UnaryTestsContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitUnaryTests_positive(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class UnaryTests_negatedContext extends UnaryTestsContext {
		public TerminalNode NOT() { return getToken(FEEL_1_1Parser.NOT, 0); }
		public TerminalNode LPAREN() { return getToken(FEEL_1_1Parser.LPAREN, 0); }
		public PositiveUnaryTestsContext positiveUnaryTests() {
			return getRuleContext(PositiveUnaryTestsContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(FEEL_1_1Parser.RPAREN, 0); }
		public UnaryTests_negatedContext(UnaryTestsContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitUnaryTests_negated(this);
			else return visitor.visitChildren(this);
		}
	}

	public final UnaryTestsContext unaryTests() throws RecognitionException {
		UnaryTestsContext _localctx = new UnaryTestsContext(_ctx, getState());
		enterRule(_localctx, 96, RULE_unaryTests);
		try {
			setState(588);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,44,_ctx) ) {
			case 1:
				_localctx = new UnaryTests_negatedContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(581);
				match(NOT);
				setState(582);
				match(LPAREN);
				setState(583);
				positiveUnaryTests();
				setState(584);
				match(RPAREN);
				}
				break;
			case 2:
				_localctx = new UnaryTests_positiveContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(586);
				positiveUnaryTests();
				}
				break;
			case 3:
				_localctx = new UnaryTests_emptyContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(587);
				match(SUB);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class EndpointContext extends ParserRuleContext {
		public AdditiveExpressionContext additiveExpression() {
			return getRuleContext(AdditiveExpressionContext.class,0);
		}
		public EndpointContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_endpoint; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitEndpoint(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EndpointContext endpoint() throws RecognitionException {
		EndpointContext _localctx = new EndpointContext(_ctx, getState());
		enterRule(_localctx, 98, RULE_endpoint);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(590);
			additiveExpression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IntervalContext extends ParserRuleContext {
		public Token low;
		public EndpointContext start;
		public EndpointContext end;
		public Token up;
		public TerminalNode ELIPSIS() { return getToken(FEEL_1_1Parser.ELIPSIS, 0); }
		public TerminalNode LPAREN() { return getToken(FEEL_1_1Parser.LPAREN, 0); }
		public List<EndpointContext> endpoint() {
			return getRuleContexts(EndpointContext.class);
		}
		public EndpointContext endpoint(int i) {
			return getRuleContext(EndpointContext.class,i);
		}
		public TerminalNode RPAREN() { return getToken(FEEL_1_1Parser.RPAREN, 0); }
		public List<TerminalNode> LBRACK() { return getTokens(FEEL_1_1Parser.LBRACK); }
		public TerminalNode LBRACK(int i) {
			return getToken(FEEL_1_1Parser.LBRACK, i);
		}
		public List<TerminalNode> RBRACK() { return getTokens(FEEL_1_1Parser.RBRACK); }
		public TerminalNode RBRACK(int i) {
			return getToken(FEEL_1_1Parser.RBRACK, i);
		}
		public IntervalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_interval; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitInterval(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IntervalContext interval() throws RecognitionException {
		IntervalContext _localctx = new IntervalContext(_ctx, getState());
		enterRule(_localctx, 100, RULE_interval);
		try {
			setState(646);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,45,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(592);
				((IntervalContext)_localctx).low = match(LPAREN);
				setState(593);
				((IntervalContext)_localctx).start = endpoint();
				setState(594);
				match(ELIPSIS);
				setState(595);
				((IntervalContext)_localctx).end = endpoint();
				setState(596);
				((IntervalContext)_localctx).up = match(RPAREN);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(598);
				((IntervalContext)_localctx).low = match(LPAREN);
				setState(599);
				((IntervalContext)_localctx).start = endpoint();
				setState(600);
				match(ELIPSIS);
				setState(601);
				((IntervalContext)_localctx).end = endpoint();
				setState(602);
				((IntervalContext)_localctx).up = match(LBRACK);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(604);
				((IntervalContext)_localctx).low = match(LPAREN);
				setState(605);
				((IntervalContext)_localctx).start = endpoint();
				setState(606);
				match(ELIPSIS);
				setState(607);
				((IntervalContext)_localctx).end = endpoint();
				setState(608);
				((IntervalContext)_localctx).up = match(RBRACK);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(610);
				((IntervalContext)_localctx).low = match(RBRACK);
				setState(611);
				((IntervalContext)_localctx).start = endpoint();
				setState(612);
				match(ELIPSIS);
				setState(613);
				((IntervalContext)_localctx).end = endpoint();
				setState(614);
				((IntervalContext)_localctx).up = match(RPAREN);
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(616);
				((IntervalContext)_localctx).low = match(RBRACK);
				setState(617);
				((IntervalContext)_localctx).start = endpoint();
				setState(618);
				match(ELIPSIS);
				setState(619);
				((IntervalContext)_localctx).end = endpoint();
				setState(620);
				((IntervalContext)_localctx).up = match(LBRACK);
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(622);
				((IntervalContext)_localctx).low = match(RBRACK);
				setState(623);
				((IntervalContext)_localctx).start = endpoint();
				setState(624);
				match(ELIPSIS);
				setState(625);
				((IntervalContext)_localctx).end = endpoint();
				setState(626);
				((IntervalContext)_localctx).up = match(RBRACK);
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(628);
				((IntervalContext)_localctx).low = match(LBRACK);
				setState(629);
				((IntervalContext)_localctx).start = endpoint();
				setState(630);
				match(ELIPSIS);
				setState(631);
				((IntervalContext)_localctx).end = endpoint();
				setState(632);
				((IntervalContext)_localctx).up = match(RPAREN);
				}
				break;
			case 8:
				enterOuterAlt(_localctx, 8);
				{
				setState(634);
				((IntervalContext)_localctx).low = match(LBRACK);
				setState(635);
				((IntervalContext)_localctx).start = endpoint();
				setState(636);
				match(ELIPSIS);
				setState(637);
				((IntervalContext)_localctx).end = endpoint();
				setState(638);
				((IntervalContext)_localctx).up = match(LBRACK);
				}
				break;
			case 9:
				enterOuterAlt(_localctx, 9);
				{
				setState(640);
				((IntervalContext)_localctx).low = match(LBRACK);
				setState(641);
				((IntervalContext)_localctx).start = endpoint();
				setState(642);
				match(ELIPSIS);
				setState(643);
				((IntervalContext)_localctx).end = endpoint();
				setState(644);
				((IntervalContext)_localctx).up = match(RBRACK);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class QualifiedNameContext extends ParserRuleContext {
		public NameRefContext n1;
		public NameRefContext n2;
		public List<NameRefContext> nameRef() {
			return getRuleContexts(NameRefContext.class);
		}
		public NameRefContext nameRef(int i) {
			return getRuleContext(NameRefContext.class,i);
		}
		public List<TerminalNode> DOT() { return getTokens(FEEL_1_1Parser.DOT); }
		public TerminalNode DOT(int i) {
			return getToken(FEEL_1_1Parser.DOT, i);
		}
		public QualifiedNameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_qualifiedName; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitQualifiedName(this);
			else return visitor.visitChildren(this);
		}
	}

	public final QualifiedNameContext qualifiedName() throws RecognitionException {
		QualifiedNameContext _localctx = new QualifiedNameContext(_ctx, getState());
		enterRule(_localctx, 102, RULE_qualifiedName);

		    String name = null;
		    int count = 0;
		    java.util.List<String> qn = new java.util.ArrayList<String>();

		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(648);
			((QualifiedNameContext)_localctx).n1 = nameRef();
			 name = getOriginalText( ((QualifiedNameContext)_localctx).n1 ); qn.add( name ); helper.validateVariable( ((QualifiedNameContext)_localctx).n1, qn, name ); 
			setState(657);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,46,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(650);
					match(DOT);
					helper.recoverScope( name ); count++;
					setState(652);
					((QualifiedNameContext)_localctx).n2 = nameRef();
					name=getOriginalText( ((QualifiedNameContext)_localctx).n2 );  qn.add( name ); helper.validateVariable( ((QualifiedNameContext)_localctx).n1, qn, name ); 
					}
					} 
				}
				setState(659);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,46,_ctx);
			}
			}
			_ctx.stop = _input.LT(-1);

			    for( int i = 0; i < count; i++ )
			        helper.dismissScope();

		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NameRefContext extends ParserRuleContext {
		public Token st;
		public Token not_st;
		public TerminalNode Identifier() { return getToken(FEEL_1_1Parser.Identifier, 0); }
		public TerminalNode NOT() { return getToken(FEEL_1_1Parser.NOT, 0); }
		public List<NameRefOtherTokenContext> nameRefOtherToken() {
			return getRuleContexts(NameRefOtherTokenContext.class);
		}
		public NameRefOtherTokenContext nameRefOtherToken(int i) {
			return getRuleContext(NameRefOtherTokenContext.class,i);
		}
		public NameRefContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_nameRef; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitNameRef(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NameRefContext nameRef() throws RecognitionException {
		NameRefContext _localctx = new NameRefContext(_ctx, getState());
		enterRule(_localctx, 104, RULE_nameRef);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(664);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case Identifier:
				{
				setState(660);
				((NameRefContext)_localctx).st = match(Identifier);
				 helper.startVariable( ((NameRefContext)_localctx).st ); 
				}
				break;
			case NOT:
				{
				setState(662);
				((NameRefContext)_localctx).not_st = match(NOT);
				 helper.startVariable( ((NameRefContext)_localctx).not_st ); 
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(669);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,48,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(666);
					nameRefOtherToken();
					}
					} 
				}
				setState(671);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,48,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NameRefOtherTokenContext extends ParserRuleContext {
		public TerminalNode LPAREN() { return getToken(FEEL_1_1Parser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(FEEL_1_1Parser.RPAREN, 0); }
		public TerminalNode LBRACK() { return getToken(FEEL_1_1Parser.LBRACK, 0); }
		public TerminalNode RBRACK() { return getToken(FEEL_1_1Parser.RBRACK, 0); }
		public TerminalNode LBRACE() { return getToken(FEEL_1_1Parser.LBRACE, 0); }
		public TerminalNode RBRACE() { return getToken(FEEL_1_1Parser.RBRACE, 0); }
		public TerminalNode LT() { return getToken(FEEL_1_1Parser.LT, 0); }
		public TerminalNode GT() { return getToken(FEEL_1_1Parser.GT, 0); }
		public TerminalNode EQUAL() { return getToken(FEEL_1_1Parser.EQUAL, 0); }
		public TerminalNode BANG() { return getToken(FEEL_1_1Parser.BANG, 0); }
		public TerminalNode COMMA() { return getToken(FEEL_1_1Parser.COMMA, 0); }
		public NameRefOtherTokenContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_nameRefOtherToken; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitNameRefOtherToken(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NameRefOtherTokenContext nameRefOtherToken() throws RecognitionException {
		NameRefOtherTokenContext _localctx = new NameRefOtherTokenContext(_ctx, getState());
		enterRule(_localctx, 106, RULE_nameRefOtherToken);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(672);
			if (!( helper.followUp( _input.LT(1), _localctx==null ) )) throw new FailedPredicateException(this, " helper.followUp( _input.LT(1), _localctx==null ) ");
			setState(673);
			_la = _input.LA(1);
			if ( _la <= 0 || ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << LPAREN) | (1L << RPAREN) | (1L << LBRACE) | (1L << RBRACE) | (1L << LBRACK) | (1L << RBRACK) | (1L << COMMA) | (1L << EQUAL) | (1L << GT) | (1L << LT) | (1L << BANG))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ReusableKeywordsContext extends ParserRuleContext {
		public TerminalNode FOR() { return getToken(FEEL_1_1Parser.FOR, 0); }
		public TerminalNode RETURN() { return getToken(FEEL_1_1Parser.RETURN, 0); }
		public TerminalNode IF() { return getToken(FEEL_1_1Parser.IF, 0); }
		public TerminalNode THEN() { return getToken(FEEL_1_1Parser.THEN, 0); }
		public TerminalNode ELSE() { return getToken(FEEL_1_1Parser.ELSE, 0); }
		public TerminalNode SOME() { return getToken(FEEL_1_1Parser.SOME, 0); }
		public TerminalNode EVERY() { return getToken(FEEL_1_1Parser.EVERY, 0); }
		public TerminalNode SATISFIES() { return getToken(FEEL_1_1Parser.SATISFIES, 0); }
		public TerminalNode INSTANCE() { return getToken(FEEL_1_1Parser.INSTANCE, 0); }
		public TerminalNode OF() { return getToken(FEEL_1_1Parser.OF, 0); }
		public TerminalNode FUNCTION() { return getToken(FEEL_1_1Parser.FUNCTION, 0); }
		public TerminalNode EXTERNAL() { return getToken(FEEL_1_1Parser.EXTERNAL, 0); }
		public TerminalNode OR() { return getToken(FEEL_1_1Parser.OR, 0); }
		public TerminalNode AND() { return getToken(FEEL_1_1Parser.AND, 0); }
		public TerminalNode BETWEEN() { return getToken(FEEL_1_1Parser.BETWEEN, 0); }
		public TerminalNode NOT() { return getToken(FEEL_1_1Parser.NOT, 0); }
		public TerminalNode NULL() { return getToken(FEEL_1_1Parser.NULL, 0); }
		public TerminalNode TRUE() { return getToken(FEEL_1_1Parser.TRUE, 0); }
		public TerminalNode FALSE() { return getToken(FEEL_1_1Parser.FALSE, 0); }
		public ReusableKeywordsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_reusableKeywords; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FEEL_1_1Visitor ) return ((FEEL_1_1Visitor<? extends T>)visitor).visitReusableKeywords(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ReusableKeywordsContext reusableKeywords() throws RecognitionException {
		ReusableKeywordsContext _localctx = new ReusableKeywordsContext(_ctx, getState());
		enterRule(_localctx, 108, RULE_reusableKeywords);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(675);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << FOR) | (1L << RETURN) | (1L << IF) | (1L << THEN) | (1L << ELSE) | (1L << SOME) | (1L << EVERY) | (1L << SATISFIES) | (1L << INSTANCE) | (1L << OF) | (1L << FUNCTION) | (1L << EXTERNAL) | (1L << OR) | (1L << AND) | (1L << BETWEEN) | (1L << NULL) | (1L << TRUE) | (1L << FALSE) | (1L << NOT))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 9:
			return iterationContext_sempred((IterationContextContext)_localctx, predIndex);
		case 27:
			return conditionalOrExpression_sempred((ConditionalOrExpressionContext)_localctx, predIndex);
		case 28:
			return conditionalAndExpression_sempred((ConditionalAndExpressionContext)_localctx, predIndex);
		case 29:
			return comparisonExpression_sempred((ComparisonExpressionContext)_localctx, predIndex);
		case 30:
			return relationalExpression_sempred((RelationalExpressionContext)_localctx, predIndex);
		case 32:
			return additiveExpression_sempred((AdditiveExpressionContext)_localctx, predIndex);
		case 33:
			return multiplicativeExpression_sempred((MultiplicativeExpressionContext)_localctx, predIndex);
		case 34:
			return powerExpression_sempred((PowerExpressionContext)_localctx, predIndex);
		case 35:
			return filterPathExpression_sempred((FilterPathExpressionContext)_localctx, predIndex);
		case 36:
			return unaryExpression_sempred((UnaryExpressionContext)_localctx, predIndex);
		case 53:
			return nameRefOtherToken_sempred((NameRefOtherTokenContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean iterationContext_sempred(IterationContextContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return helper.isFeatDMN12EnhancedForLoopEnabled();
		}
		return true;
	}
	private boolean conditionalOrExpression_sempred(ConditionalOrExpressionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 1:
			return precpred(_ctx, 1);
		}
		return true;
	}
	private boolean conditionalAndExpression_sempred(ConditionalAndExpressionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 2:
			return precpred(_ctx, 1);
		}
		return true;
	}
	private boolean comparisonExpression_sempred(ComparisonExpressionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 3:
			return precpred(_ctx, 1);
		}
		return true;
	}
	private boolean relationalExpression_sempred(RelationalExpressionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 4:
			return precpred(_ctx, 4);
		case 5:
			return precpred(_ctx, 3);
		case 6:
			return precpred(_ctx, 2);
		case 7:
			return precpred(_ctx, 1);
		}
		return true;
	}
	private boolean additiveExpression_sempred(AdditiveExpressionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 8:
			return precpred(_ctx, 2);
		case 9:
			return precpred(_ctx, 1);
		}
		return true;
	}
	private boolean multiplicativeExpression_sempred(MultiplicativeExpressionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 10:
			return precpred(_ctx, 1);
		}
		return true;
	}
	private boolean powerExpression_sempred(PowerExpressionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 11:
			return precpred(_ctx, 1);
		}
		return true;
	}
	private boolean filterPathExpression_sempred(FilterPathExpressionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 12:
			return precpred(_ctx, 2);
		case 13:
			return precpred(_ctx, 1);
		}
		return true;
	}
	private boolean unaryExpression_sempred(UnaryExpressionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 14:
			return precpred(_ctx, 4);
		}
		return true;
	}
	private boolean nameRefOtherToken_sempred(NameRefOtherTokenContext _localctx, int predIndex) {
		switch (predIndex) {
		case 15:
			return  helper.followUp( _input.LT(1), _localctx==null ) ;
		}
		return true;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\38\u02a8\4\2\t\2\4"+
		"\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t"+
		"\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36\t\36\4\37\t\37\4 \t \4!"+
		"\t!\4\"\t\"\4#\t#\4$\t$\4%\t%\4&\t&\4\'\t\'\4(\t(\4)\t)\4*\t*\4+\t+\4"+
		",\t,\4-\t-\4.\t.\4/\t/\4\60\t\60\4\61\t\61\4\62\t\62\4\63\t\63\4\64\t"+
		"\64\4\65\t\65\4\66\t\66\4\67\t\67\48\t8\3\2\3\2\3\2\3\3\3\3\3\4\3\4\5"+
		"\4x\n\4\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\5\5\u0084\n\5\3\6\3\6"+
		"\3\6\7\6\u0089\n\6\f\6\16\6\u008c\13\6\3\7\3\7\3\7\3\7\3\b\3\b\3\b\7\b"+
		"\u0095\n\b\f\b\16\b\u0098\13\b\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\n\3\n\3\n"+
		"\7\n\u00a4\n\n\f\n\16\n\u00a7\13\n\3\13\3\13\3\13\3\13\3\13\3\13\3\13"+
		"\3\13\3\13\3\13\3\13\5\13\u00b4\n\13\3\f\3\f\3\f\3\f\3\f\3\f\3\f\3\r\3"+
		"\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\5\r\u00cb\n\r\3\16"+
		"\3\16\3\16\3\16\3\16\3\16\3\16\3\16\3\16\3\16\3\16\3\16\3\16\3\16\3\16"+
		"\3\16\7\16\u00dd\n\16\f\16\16\16\u00e0\13\16\3\16\3\16\3\16\3\16\3\16"+
		"\3\16\3\16\3\16\7\16\u00ea\n\16\f\16\16\16\u00ed\13\16\3\16\3\16\3\16"+
		"\3\16\3\16\5\16\u00f4\n\16\3\17\3\17\3\17\3\17\3\17\3\17\5\17\u00fc\n"+
		"\17\3\20\3\20\3\20\5\20\u0101\n\20\3\20\3\20\5\20\u0105\n\20\3\20\3\20"+
		"\3\20\3\20\3\21\3\21\3\21\7\21\u010e\n\21\f\21\16\21\u0111\13\21\3\22"+
		"\3\22\3\22\3\22\3\22\5\22\u0118\n\22\3\23\3\23\3\23\3\23\3\23\3\23\5\23"+
		"\u0120\n\23\3\24\3\24\3\24\7\24\u0125\n\24\f\24\16\24\u0128\13\24\3\25"+
		"\3\25\3\25\3\25\3\25\3\25\3\26\3\26\5\26\u0132\n\26\3\27\3\27\3\27\3\30"+
		"\3\30\3\30\3\31\3\31\3\31\3\31\3\31\3\31\3\31\7\31\u0141\n\31\f\31\16"+
		"\31\u0144\13\31\3\32\3\32\3\32\3\33\3\33\3\33\3\33\3\33\3\33\7\33\u014f"+
		"\n\33\f\33\16\33\u0152\13\33\3\34\3\34\3\35\3\35\3\35\3\35\3\35\3\35\7"+
		"\35\u015c\n\35\f\35\16\35\u015f\13\35\3\36\3\36\3\36\3\36\3\36\3\36\7"+
		"\36\u0167\n\36\f\36\16\36\u016a\13\36\3\37\3\37\3\37\3\37\3\37\3\37\7"+
		"\37\u0172\n\37\f\37\16\37\u0175\13\37\3 \3 \3 \3 \3 \3 \3 \3 \3 \3 \3"+
		" \3 \3 \3 \3 \3 \3 \3 \3 \3 \3 \3 \7 \u018d\n \f \16 \u0190\13 \3!\3!"+
		"\3!\7!\u0195\n!\f!\16!\u0198\13!\3\"\3\"\3\"\3\"\3\"\3\"\3\"\3\"\3\"\7"+
		"\"\u01a3\n\"\f\"\16\"\u01a6\13\"\3#\3#\3#\3#\3#\3#\7#\u01ae\n#\f#\16#"+
		"\u01b1\13#\3$\3$\3$\3$\3$\3$\7$\u01b9\n$\f$\16$\u01bc\13$\3%\3%\3%\3%"+
		"\3%\3%\3%\3%\3%\3%\3%\3%\3%\3%\3%\3%\7%\u01ce\n%\f%\16%\u01d1\13%\3&\3"+
		"&\3&\3&\3&\3&\5&\u01d9\n&\3&\3&\7&\u01dd\n&\f&\16&\u01e0\13&\3\'\3\'\3"+
		"\'\3\'\3\'\5\'\u01e7\n\'\3\'\3\'\5\'\u01eb\n\'\3(\3(\3(\3(\3(\3(\3(\3"+
		"(\3(\3(\3(\3(\3(\5(\u01fa\n(\3)\3)\3)\3)\3)\3)\5)\u0202\n)\3*\3*\3*\3"+
		"+\3+\3,\3,\3,\3,\3,\3,\3,\3,\3,\3,\3,\3,\3,\3,\3,\3,\3,\3,\3,\3,\3,\3"+
		",\3,\3,\3,\3,\3,\3,\3,\3,\3,\5,\u0228\n,\3-\3-\3-\7-\u022d\n-\f-\16-\u0230"+
		"\13-\3.\3.\3.\3.\3.\3.\3.\5.\u0239\n.\3/\3/\3\60\3\60\3\60\7\60\u0240"+
		"\n\60\f\60\16\60\u0243\13\60\3\61\3\61\3\61\3\62\3\62\3\62\3\62\3\62\3"+
		"\62\3\62\5\62\u024f\n\62\3\63\3\63\3\64\3\64\3\64\3\64\3\64\3\64\3\64"+
		"\3\64\3\64\3\64\3\64\3\64\3\64\3\64\3\64\3\64\3\64\3\64\3\64\3\64\3\64"+
		"\3\64\3\64\3\64\3\64\3\64\3\64\3\64\3\64\3\64\3\64\3\64\3\64\3\64\3\64"+
		"\3\64\3\64\3\64\3\64\3\64\3\64\3\64\3\64\3\64\3\64\3\64\3\64\3\64\3\64"+
		"\3\64\3\64\3\64\3\64\3\64\5\64\u0289\n\64\3\65\3\65\3\65\3\65\3\65\3\65"+
		"\3\65\7\65\u0292\n\65\f\65\16\65\u0295\13\65\3\66\3\66\3\66\3\66\5\66"+
		"\u029b\n\66\3\66\7\66\u029e\n\66\f\66\16\66\u02a1\13\66\3\67\3\67\3\67"+
		"\38\38\38\2\138:<>BDFHJ9\2\4\6\b\n\f\16\20\22\24\26\30\32\34\36 \"$&("+
		"*,.\60\62\64\668:<>@BDFHJLNPRTVXZ\\^`bdfhjln\2\7\5\2\27\27##-\60\3\2$"+
		")\3\2/\60\5\2\33!$&\61\61\5\2\4\5\7\26\62\62\2\u02c9\2p\3\2\2\2\4s\3\2"+
		"\2\2\6w\3\2\2\2\b\u0083\3\2\2\2\n\u0085\3\2\2\2\f\u008d\3\2\2\2\16\u0091"+
		"\3\2\2\2\20\u0099\3\2\2\2\22\u00a0\3\2\2\2\24\u00b3\3\2\2\2\26\u00b5\3"+
		"\2\2\2\30\u00ca\3\2\2\2\32\u00f3\3\2\2\2\34\u00fb\3\2\2\2\36\u00fd\3\2"+
		"\2\2 \u010a\3\2\2\2\"\u0117\3\2\2\2$\u011f\3\2\2\2&\u0121\3\2\2\2(\u0129"+
		"\3\2\2\2*\u0131\3\2\2\2,\u0133\3\2\2\2.\u0136\3\2\2\2\60\u0139\3\2\2\2"+
		"\62\u0145\3\2\2\2\64\u0148\3\2\2\2\66\u0153\3\2\2\28\u0155\3\2\2\2:\u0160"+
		"\3\2\2\2<\u016b\3\2\2\2>\u0176\3\2\2\2@\u0191\3\2\2\2B\u0199\3\2\2\2D"+
		"\u01a7\3\2\2\2F\u01b2\3\2\2\2H\u01bd\3\2\2\2J\u01d8\3\2\2\2L\u01e1\3\2"+
		"\2\2N\u01f9\3\2\2\2P\u0201\3\2\2\2R\u0203\3\2\2\2T\u0206\3\2\2\2V\u0227"+
		"\3\2\2\2X\u0229\3\2\2\2Z\u0238\3\2\2\2\\\u023a\3\2\2\2^\u023c\3\2\2\2"+
		"`\u0244\3\2\2\2b\u024e\3\2\2\2d\u0250\3\2\2\2f\u0288\3\2\2\2h\u028a\3"+
		"\2\2\2j\u029a\3\2\2\2l\u02a2\3\2\2\2n\u02a5\3\2\2\2pq\5\4\3\2qr\7\2\2"+
		"\3r\3\3\2\2\2st\5\6\4\2t\5\3\2\2\2ux\5\36\20\2vx\58\35\2wu\3\2\2\2wv\3"+
		"\2\2\2x\7\3\2\2\2yz\7\33\2\2z\u0084\7\34\2\2{|\7\33\2\2|}\5\n\6\2}~\7"+
		"\34\2\2~\u0084\3\2\2\2\177\u0080\7\33\2\2\u0080\u0081\5\16\b\2\u0081\u0082"+
		"\7\34\2\2\u0082\u0084\3\2\2\2\u0083y\3\2\2\2\u0083{\3\2\2\2\u0083\177"+
		"\3\2\2\2\u0084\t\3\2\2\2\u0085\u008a\5\f\7\2\u0086\u0087\7!\2\2\u0087"+
		"\u0089\5\f\7\2\u0088\u0086\3\2\2\2\u0089\u008c\3\2\2\2\u008a\u0088\3\2"+
		"\2\2\u008a\u008b\3\2\2\2\u008b\13\3\2\2\2\u008c\u008a\3\2\2\2\u008d\u008e"+
		"\5,\27\2\u008e\u008f\7*\2\2\u008f\u0090\5\4\3\2\u0090\r\3\2\2\2\u0091"+
		"\u0096\5\4\3\2\u0092\u0093\7!\2\2\u0093\u0095\5\4\3\2\u0094\u0092\3\2"+
		"\2\2\u0095\u0098\3\2\2\2\u0096\u0094\3\2\2\2\u0096\u0097\3\2\2\2\u0097"+
		"\17\3\2\2\2\u0098\u0096\3\2\2\2\u0099\u009a\7\4\2\2\u009a\u009b\5\22\n"+
		"\2\u009b\u009c\7\5\2\2\u009c\u009d\b\t\1\2\u009d\u009e\5\4\3\2\u009e\u009f"+
		"\b\t\1\2\u009f\21\3\2\2\2\u00a0\u00a5\5\24\13\2\u00a1\u00a2\7!\2\2\u00a2"+
		"\u00a4\5\24\13\2\u00a3\u00a1\3\2\2\2\u00a4\u00a7\3\2\2\2\u00a5\u00a3\3"+
		"\2\2\2\u00a5\u00a6\3\2\2\2\u00a6\23\3\2\2\2\u00a7\u00a5\3\2\2\2\u00a8"+
		"\u00a9\6\13\2\2\u00a9\u00aa\5\62\32\2\u00aa\u00ab\7\6\2\2\u00ab\u00ac"+
		"\5\4\3\2\u00ac\u00ad\7\"\2\2\u00ad\u00ae\5\4\3\2\u00ae\u00b4\3\2\2\2\u00af"+
		"\u00b0\5\62\32\2\u00b0\u00b1\7\6\2\2\u00b1\u00b2\5\4\3\2\u00b2\u00b4\3"+
		"\2\2\2\u00b3\u00a8\3\2\2\2\u00b3\u00af\3\2\2\2\u00b4\25\3\2\2\2\u00b5"+
		"\u00b6\7\7\2\2\u00b6\u00b7\5\4\3\2\u00b7\u00b8\7\b\2\2\u00b8\u00b9\5\4"+
		"\3\2\u00b9\u00ba\7\t\2\2\u00ba\u00bb\5\4\3\2\u00bb\27\3\2\2\2\u00bc\u00bd"+
		"\7\n\2\2\u00bd\u00be\5\22\n\2\u00be\u00bf\7\f\2\2\u00bf\u00c0\b\r\1\2"+
		"\u00c0\u00c1\5\4\3\2\u00c1\u00c2\b\r\1\2\u00c2\u00cb\3\2\2\2\u00c3\u00c4"+
		"\7\13\2\2\u00c4\u00c5\5\22\n\2\u00c5\u00c6\7\f\2\2\u00c6\u00c7\b\r\1\2"+
		"\u00c7\u00c8\5\4\3\2\u00c8\u00c9\b\r\1\2\u00c9\u00cb\3\2\2\2\u00ca\u00bc"+
		"\3\2\2\2\u00ca\u00c3\3\2\2\2\u00cb\31\3\2\2\2\u00cc\u00cd\7\64\2\2\u00cd"+
		"\u00ce\b\16\1\2\u00ce\u00cf\7&\2\2\u00cf\u00d0\5\32\16\2\u00d0\u00d1\7"+
		"%\2\2\u00d1\u00f4\3\2\2\2\u00d2\u00d3\7\64\2\2\u00d3\u00d4\b\16\1\2\u00d4"+
		"\u00d5\7&\2\2\u00d5\u00d6\7\64\2\2\u00d6\u00d7\7*\2\2\u00d7\u00de\5\32"+
		"\16\2\u00d8\u00d9\7!\2\2\u00d9\u00da\7\64\2\2\u00da\u00db\7*\2\2\u00db"+
		"\u00dd\5\32\16\2\u00dc\u00d8\3\2\2\2\u00dd\u00e0\3\2\2\2\u00de\u00dc\3"+
		"\2\2\2\u00de\u00df\3\2\2\2\u00df\u00e1\3\2\2\2\u00e0\u00de\3\2\2\2\u00e1"+
		"\u00e2\7%\2\2\u00e2\u00f4\3\2\2\2\u00e3\u00f4\7\17\2\2\u00e4\u00e5\7\17"+
		"\2\2\u00e5\u00e6\7&\2\2\u00e6\u00eb\5\32\16\2\u00e7\u00e8\7!\2\2\u00e8"+
		"\u00ea\5\32\16\2\u00e9\u00e7\3\2\2\2\u00ea\u00ed\3\2\2\2\u00eb\u00e9\3"+
		"\2\2\2\u00eb\u00ec\3\2\2\2\u00ec\u00ee\3\2\2\2\u00ed\u00eb\3\2\2\2\u00ee"+
		"\u00ef\7%\2\2\u00ef\u00f0\7+\2\2\u00f0\u00f1\5\32\16\2\u00f1\u00f4\3\2"+
		"\2\2\u00f2\u00f4\5h\65\2\u00f3\u00cc\3\2\2\2\u00f3\u00d2\3\2\2\2\u00f3"+
		"\u00e3\3\2\2\2\u00f3\u00e4\3\2\2\2\u00f3\u00f2\3\2\2\2\u00f4\33\3\2\2"+
		"\2\u00f5\u00f6\7\37\2\2\u00f6\u00fc\7 \2\2\u00f7\u00f8\7\37\2\2\u00f8"+
		"\u00f9\5@!\2\u00f9\u00fa\7 \2\2\u00fa\u00fc\3\2\2\2\u00fb\u00f5\3\2\2"+
		"\2\u00fb\u00f7\3\2\2\2\u00fc\35\3\2\2\2\u00fd\u00fe\7\17\2\2\u00fe\u0100"+
		"\7\33\2\2\u00ff\u0101\5 \21\2\u0100\u00ff\3\2\2\2\u0100\u0101\3\2\2\2"+
		"\u0101\u0102\3\2\2\2\u0102\u0104\7\34\2\2\u0103\u0105\7\20\2\2\u0104\u0103"+
		"\3\2\2\2\u0104\u0105\3\2\2\2\u0105\u0106\3\2\2\2\u0106\u0107\b\20\1\2"+
		"\u0107\u0108\5\4\3\2\u0108\u0109\b\20\1\2\u0109\37\3\2\2\2\u010a\u010f"+
		"\5\"\22\2\u010b\u010c\7!\2\2\u010c\u010e\5\"\22\2\u010d\u010b\3\2\2\2"+
		"\u010e\u0111\3\2\2\2\u010f\u010d\3\2\2\2\u010f\u0110\3\2\2\2\u0110!\3"+
		"\2\2\2\u0111\u010f\3\2\2\2\u0112\u0113\5,\27\2\u0113\u0114\7*\2\2\u0114"+
		"\u0115\5\32\16\2\u0115\u0118\3\2\2\2\u0116\u0118\5,\27\2\u0117\u0112\3"+
		"\2\2\2\u0117\u0116\3\2\2\2\u0118#\3\2\2\2\u0119\u011a\7\35\2\2\u011a\u0120"+
		"\7\36\2\2\u011b\u011c\7\35\2\2\u011c\u011d\5&\24\2\u011d\u011e\7\36\2"+
		"\2\u011e\u0120\3\2\2\2\u011f\u0119\3\2\2\2\u011f\u011b\3\2\2\2\u0120%"+
		"\3\2\2\2\u0121\u0126\5(\25\2\u0122\u0123\7!\2\2\u0123\u0125\5(\25\2\u0124"+
		"\u0122\3\2\2\2\u0125\u0128\3\2\2\2\u0126\u0124\3\2\2\2\u0126\u0127\3\2"+
		"\2\2\u0127\'\3\2\2\2\u0128\u0126\3\2\2\2\u0129\u012a\5*\26\2\u012a\u012b"+
		"\b\25\1\2\u012b\u012c\7*\2\2\u012c\u012d\5\4\3\2\u012d\u012e\b\25\1\2"+
		"\u012e)\3\2\2\2\u012f\u0132\5,\27\2\u0130\u0132\7\32\2\2\u0131\u012f\3"+
		"\2\2\2\u0131\u0130\3\2\2\2\u0132+\3\2\2\2\u0133\u0134\5\60\31\2\u0134"+
		"\u0135\b\27\1\2\u0135-\3\2\2\2\u0136\u0137\5,\27\2\u0137\u0138\7\2\2\3"+
		"\u0138/\3\2\2\2\u0139\u0142\7\64\2\2\u013a\u0141\7\64\2\2\u013b\u0141"+
		"\5\66\34\2\u013c\u0141\7\30\2\2\u013d\u0141\7\31\2\2\u013e\u0141\5n8\2"+
		"\u013f\u0141\7\6\2\2\u0140\u013a\3\2\2\2\u0140\u013b\3\2\2\2\u0140\u013c"+
		"\3\2\2\2\u0140\u013d\3\2\2\2\u0140\u013e\3\2\2\2\u0140\u013f\3\2\2\2\u0141"+
		"\u0144\3\2\2\2\u0142\u0140\3\2\2\2\u0142\u0143\3\2\2\2\u0143\61\3\2\2"+
		"\2\u0144\u0142\3\2\2\2\u0145\u0146\5\64\33\2\u0146\u0147\b\32\1\2\u0147"+
		"\63\3\2\2\2\u0148\u0150\7\64\2\2\u0149\u014f\7\64\2\2\u014a\u014f\5\66"+
		"\34\2\u014b\u014f\7\30\2\2\u014c\u014f\7\31\2\2\u014d\u014f\5n8\2\u014e"+
		"\u0149\3\2\2\2\u014e\u014a\3\2\2\2\u014e\u014b\3\2\2\2\u014e\u014c\3\2"+
		"\2\2\u014e\u014d\3\2\2\2\u014f\u0152\3\2\2\2\u0150\u014e\3\2\2\2\u0150"+
		"\u0151\3\2\2\2\u0151\65\3\2\2\2\u0152\u0150\3\2\2\2\u0153\u0154\t\2\2"+
		"\2\u0154\67\3\2\2\2\u0155\u0156\b\35\1\2\u0156\u0157\5:\36\2\u0157\u015d"+
		"\3\2\2\2\u0158\u0159\f\3\2\2\u0159\u015a\7\21\2\2\u015a\u015c\5:\36\2"+
		"\u015b\u0158\3\2\2\2\u015c\u015f\3\2\2\2\u015d\u015b\3\2\2\2\u015d\u015e"+
		"\3\2\2\2\u015e9\3\2\2\2\u015f\u015d\3\2\2\2\u0160\u0161\b\36\1\2\u0161"+
		"\u0162\5<\37\2\u0162\u0168\3\2\2\2\u0163\u0164\f\3\2\2\u0164\u0165\7\22"+
		"\2\2\u0165\u0167\5<\37\2\u0166\u0163\3\2\2\2\u0167\u016a\3\2\2\2\u0168"+
		"\u0166\3\2\2\2\u0168\u0169\3\2\2\2\u0169;\3\2\2\2\u016a\u0168\3\2\2\2"+
		"\u016b\u016c\b\37\1\2\u016c\u016d\5> \2\u016d\u0173\3\2\2\2\u016e\u016f"+
		"\f\3\2\2\u016f\u0170\t\3\2\2\u0170\u0172\5> \2\u0171\u016e\3\2\2\2\u0172"+
		"\u0175\3\2\2\2\u0173\u0171\3\2\2\2\u0173\u0174\3\2\2\2\u0174=\3\2\2\2"+
		"\u0175\u0173\3\2\2\2\u0176\u0177\b \1\2\u0177\u0178\5B\"\2\u0178\u018e"+
		"\3\2\2\2\u0179\u017a\f\6\2\2\u017a\u017b\7\23\2\2\u017b\u017c\5B\"\2\u017c"+
		"\u017d\7\22\2\2\u017d\u017e\5B\"\2\u017e\u018d\3\2\2\2\u017f\u0180\f\5"+
		"\2\2\u0180\u0181\7\6\2\2\u0181\u0182\7\33\2\2\u0182\u0183\5^\60\2\u0183"+
		"\u0184\7\34\2\2\u0184\u018d\3\2\2\2\u0185\u0186\f\4\2\2\u0186\u0187\7"+
		"\6\2\2\u0187\u018d\5\4\3\2\u0188\u0189\f\3\2\2\u0189\u018a\7\r\2\2\u018a"+
		"\u018b\7\16\2\2\u018b\u018d\5\32\16\2\u018c\u0179\3\2\2\2\u018c\u017f"+
		"\3\2\2\2\u018c\u0185\3\2\2\2\u018c\u0188\3\2\2\2\u018d\u0190\3\2\2\2\u018e"+
		"\u018c\3\2\2\2\u018e\u018f\3\2\2\2\u018f?\3\2\2\2\u0190\u018e\3\2\2\2"+
		"\u0191\u0196\5\4\3\2\u0192\u0193\7!\2\2\u0193\u0195\5\4\3\2\u0194\u0192"+
		"\3\2\2\2\u0195\u0198\3\2\2\2\u0196\u0194\3\2\2\2\u0196\u0197\3\2\2\2\u0197"+
		"A\3\2\2\2\u0198\u0196\3\2\2\2\u0199\u019a\b\"\1\2\u019a\u019b\5D#\2\u019b"+
		"\u01a4\3\2\2\2\u019c\u019d\f\4\2\2\u019d\u019e\7-\2\2\u019e\u01a3\5D#"+
		"\2\u019f\u01a0\f\3\2\2\u01a0\u01a1\7.\2\2\u01a1\u01a3\5D#\2\u01a2\u019c"+
		"\3\2\2\2\u01a2\u019f\3\2\2\2\u01a3\u01a6\3\2\2\2\u01a4\u01a2\3\2\2\2\u01a4"+
		"\u01a5\3\2\2\2\u01a5C\3\2\2\2\u01a6\u01a4\3\2\2\2\u01a7\u01a8\b#\1\2\u01a8"+
		"\u01a9\5F$\2\u01a9\u01af\3\2\2\2\u01aa\u01ab\f\3\2\2\u01ab\u01ac\t\4\2"+
		"\2\u01ac\u01ae\5F$\2\u01ad\u01aa\3\2\2\2\u01ae\u01b1\3\2\2\2\u01af\u01ad"+
		"\3\2\2\2\u01af\u01b0\3\2\2\2\u01b0E\3\2\2\2\u01b1\u01af\3\2\2\2\u01b2"+
		"\u01b3\b$\1\2\u01b3\u01b4\5H%\2\u01b4\u01ba\3\2\2\2\u01b5\u01b6\f\3\2"+
		"\2\u01b6\u01b7\7,\2\2\u01b7\u01b9\5H%\2\u01b8\u01b5\3\2\2\2\u01b9\u01bc"+
		"\3\2\2\2\u01ba\u01b8\3\2\2\2\u01ba\u01bb\3\2\2\2\u01bbG\3\2\2\2\u01bc"+
		"\u01ba\3\2\2\2\u01bd\u01be\b%\1\2\u01be\u01bf\5J&\2\u01bf\u01cf\3\2\2"+
		"\2\u01c0\u01c1\f\4\2\2\u01c1\u01c2\7\37\2\2\u01c2\u01c3\b%\1\2\u01c3\u01c4"+
		"\5\4\3\2\u01c4\u01c5\b%\1\2\u01c5\u01c6\7 \2\2\u01c6\u01ce\3\2\2\2\u01c7"+
		"\u01c8\f\3\2\2\u01c8\u01c9\7#\2\2\u01c9\u01ca\b%\1\2\u01ca\u01cb\5h\65"+
		"\2\u01cb\u01cc\b%\1\2\u01cc\u01ce\3\2\2\2\u01cd\u01c0\3\2\2\2\u01cd\u01c7"+
		"\3\2\2\2\u01ce\u01d1\3\2\2\2\u01cf\u01cd\3\2\2\2\u01cf\u01d0\3\2\2\2\u01d0"+
		"I\3\2\2\2\u01d1\u01cf\3\2\2\2\u01d2\u01d3\b&\1\2\u01d3\u01d4\7.\2\2\u01d4"+
		"\u01d9\5J&\5\u01d5\u01d9\5L\'\2\u01d6\u01d7\7-\2\2\u01d7\u01d9\5L\'\2"+
		"\u01d8\u01d2\3\2\2\2\u01d8\u01d5\3\2\2\2\u01d8\u01d6\3\2\2\2\u01d9\u01de"+
		"\3\2\2\2\u01da\u01db\f\6\2\2\u01db\u01dd\5\b\5\2\u01dc\u01da\3\2\2\2\u01dd"+
		"\u01e0\3\2\2\2\u01de\u01dc\3\2\2\2\u01de\u01df\3\2\2\2\u01dfK\3\2\2\2"+
		"\u01e0\u01de\3\2\2\2\u01e1\u01ea\5N(\2\u01e2\u01e3\7#\2\2\u01e3\u01e4"+
		"\b\'\1\2\u01e4\u01e6\5h\65\2\u01e5\u01e7\5\b\5\2\u01e6\u01e5\3\2\2\2\u01e6"+
		"\u01e7\3\2\2\2\u01e7\u01e8\3\2\2\2\u01e8\u01e9\b\'\1\2\u01e9\u01eb\3\2"+
		"\2\2\u01ea\u01e2\3\2\2\2\u01ea\u01eb\3\2\2\2\u01ebM\3\2\2\2\u01ec\u01fa"+
		"\5P)\2\u01ed\u01fa\5\20\t\2\u01ee\u01fa\5\30\r\2\u01ef\u01fa\5\26\f\2"+
		"\u01f0\u01fa\5f\64\2\u01f1\u01fa\5\34\17\2\u01f2\u01fa\5$\23\2\u01f3\u01f4"+
		"\7\33\2\2\u01f4\u01f5\5\4\3\2\u01f5\u01f6\7\34\2\2\u01f6\u01fa\3\2\2\2"+
		"\u01f7\u01fa\5V,\2\u01f8\u01fa\5h\65\2\u01f9\u01ec\3\2\2\2\u01f9\u01ed"+
		"\3\2\2\2\u01f9\u01ee\3\2\2\2\u01f9\u01ef\3\2\2\2\u01f9\u01f0\3\2\2\2\u01f9"+
		"\u01f1\3\2\2\2\u01f9\u01f2\3\2\2\2\u01f9\u01f3\3\2\2\2\u01f9\u01f7\3\2"+
		"\2\2\u01f9\u01f8\3\2\2\2\u01faO\3\2\2\2\u01fb\u0202\7\30\2\2\u01fc\u0202"+
		"\7\31\2\2\u01fd\u0202\7\3\2\2\u01fe\u0202\5R*\2\u01ff\u0202\7\32\2\2\u0200"+
		"\u0202\7\24\2\2\u0201\u01fb\3\2\2\2\u0201\u01fc\3\2\2\2\u0201\u01fd\3"+
		"\2\2\2\u0201\u01fe\3\2\2\2\u0201\u01ff\3\2\2\2\u0201\u0200\3\2\2\2\u0202"+
		"Q\3\2\2\2\u0203\u0204\7\63\2\2\u0204\u0205\5T+\2\u0205S\3\2\2\2\u0206"+
		"\u0207\7\32\2\2\u0207U\3\2\2\2\u0208\u0209\7&\2\2\u0209\u020a\b,\1\2\u020a"+
		"\u020b\5d\63\2\u020b\u020c\b,\1\2\u020c\u0228\3\2\2\2\u020d\u020e\7%\2"+
		"\2\u020e\u020f\b,\1\2\u020f\u0210\5d\63\2\u0210\u0211\b,\1\2\u0211\u0228"+
		"\3\2\2\2\u0212\u0213\7\'\2\2\u0213\u0214\b,\1\2\u0214\u0215\5d\63\2\u0215"+
		"\u0216\b,\1\2\u0216\u0228\3\2\2\2\u0217\u0218\7(\2\2\u0218\u0219\b,\1"+
		"\2\u0219\u021a\5d\63\2\u021a\u021b\b,\1\2\u021b\u0228\3\2\2\2\u021c\u021d"+
		"\7$\2\2\u021d\u021e\b,\1\2\u021e\u021f\5d\63\2\u021f\u0220\b,\1\2\u0220"+
		"\u0228\3\2\2\2\u0221\u0222\7)\2\2\u0222\u0223\b,\1\2\u0223\u0224\5d\63"+
		"\2\u0224\u0225\b,\1\2\u0225\u0228\3\2\2\2\u0226\u0228\5f\64\2\u0227\u0208"+
		"\3\2\2\2\u0227\u020d\3\2\2\2\u0227\u0212\3\2\2\2\u0227\u0217\3\2\2\2\u0227"+
		"\u021c\3\2\2\2\u0227\u0221\3\2\2\2\u0227\u0226\3\2\2\2\u0228W\3\2\2\2"+
		"\u0229\u022e\5V,\2\u022a\u022b\7!\2\2\u022b\u022d\5V,\2\u022c\u022a\3"+
		"\2\2\2\u022d\u0230\3\2\2\2\u022e\u022c\3\2\2\2\u022e\u022f\3\2\2\2\u022f"+
		"Y\3\2\2\2\u0230\u022e\3\2\2\2\u0231\u0239\5X-\2\u0232\u0233\7\62\2\2\u0233"+
		"\u0234\7\33\2\2\u0234\u0235\5X-\2\u0235\u0236\7\34\2\2\u0236\u0239\3\2"+
		"\2\2\u0237\u0239\7.\2\2\u0238\u0231\3\2\2\2\u0238\u0232\3\2\2\2\u0238"+
		"\u0237\3\2\2\2\u0239[\3\2\2\2\u023a\u023b\5\4\3\2\u023b]\3\2\2\2\u023c"+
		"\u0241\5\\/\2\u023d\u023e\7!\2\2\u023e\u0240\5\\/\2\u023f\u023d\3\2\2"+
		"\2\u0240\u0243\3\2\2\2\u0241\u023f\3\2\2\2\u0241\u0242\3\2\2\2\u0242_"+
		"\3\2\2\2\u0243\u0241\3\2\2\2\u0244\u0245\5b\62\2\u0245\u0246\7\2\2\3\u0246"+
		"a\3\2\2\2\u0247\u0248\7\62\2\2\u0248\u0249\7\33\2\2\u0249\u024a\5^\60"+
		"\2\u024a\u024b\7\34\2\2\u024b\u024f\3\2\2\2\u024c\u024f\5^\60\2\u024d"+
		"\u024f\7.\2\2\u024e\u0247\3\2\2\2\u024e\u024c\3\2\2\2\u024e\u024d\3\2"+
		"\2\2\u024fc\3\2\2\2\u0250\u0251\5B\"\2\u0251e\3\2\2\2\u0252\u0253\7\33"+
		"\2\2\u0253\u0254\5d\63\2\u0254\u0255\7\"\2\2\u0255\u0256\5d\63\2\u0256"+
		"\u0257\7\34\2\2\u0257\u0289\3\2\2\2\u0258\u0259\7\33\2\2\u0259\u025a\5"+
		"d\63\2\u025a\u025b\7\"\2\2\u025b\u025c\5d\63\2\u025c\u025d\7\37\2\2\u025d"+
		"\u0289\3\2\2\2\u025e\u025f\7\33\2\2\u025f\u0260\5d\63\2\u0260\u0261\7"+
		"\"\2\2\u0261\u0262\5d\63\2\u0262\u0263\7 \2\2\u0263\u0289\3\2\2\2\u0264"+
		"\u0265\7 \2\2\u0265\u0266\5d\63\2\u0266\u0267\7\"\2\2\u0267\u0268\5d\63"+
		"\2\u0268\u0269\7\34\2\2\u0269\u0289\3\2\2\2\u026a\u026b\7 \2\2\u026b\u026c"+
		"\5d\63\2\u026c\u026d\7\"\2\2\u026d\u026e\5d\63\2\u026e\u026f\7\37\2\2"+
		"\u026f\u0289\3\2\2\2\u0270\u0271\7 \2\2\u0271\u0272\5d\63\2\u0272\u0273"+
		"\7\"\2\2\u0273\u0274\5d\63\2\u0274\u0275\7 \2\2\u0275\u0289\3\2\2\2\u0276"+
		"\u0277\7\37\2\2\u0277\u0278\5d\63\2\u0278\u0279\7\"\2\2\u0279\u027a\5"+
		"d\63\2\u027a\u027b\7\34\2\2\u027b\u0289\3\2\2\2\u027c\u027d\7\37\2\2\u027d"+
		"\u027e\5d\63\2\u027e\u027f\7\"\2\2\u027f\u0280\5d\63\2\u0280\u0281\7\37"+
		"\2\2\u0281\u0289\3\2\2\2\u0282\u0283\7\37\2\2\u0283\u0284\5d\63\2\u0284"+
		"\u0285\7\"\2\2\u0285\u0286\5d\63\2\u0286\u0287\7 \2\2\u0287\u0289\3\2"+
		"\2\2\u0288\u0252\3\2\2\2\u0288\u0258\3\2\2\2\u0288\u025e\3\2\2\2\u0288"+
		"\u0264\3\2\2\2\u0288\u026a\3\2\2\2\u0288\u0270\3\2\2\2\u0288\u0276\3\2"+
		"\2\2\u0288\u027c\3\2\2\2\u0288\u0282\3\2\2\2\u0289g\3\2\2\2\u028a\u028b"+
		"\5j\66\2\u028b\u0293\b\65\1\2\u028c\u028d\7#\2\2\u028d\u028e\b\65\1\2"+
		"\u028e\u028f\5j\66\2\u028f\u0290\b\65\1\2\u0290\u0292\3\2\2\2\u0291\u028c"+
		"\3\2\2\2\u0292\u0295\3\2\2\2\u0293\u0291\3\2\2\2\u0293\u0294\3\2\2\2\u0294"+
		"i\3\2\2\2\u0295\u0293\3\2\2\2\u0296\u0297\7\64\2\2\u0297\u029b\b\66\1"+
		"\2\u0298\u0299\7\62\2\2\u0299\u029b\b\66\1\2\u029a\u0296\3\2\2\2\u029a"+
		"\u0298\3\2\2\2\u029b\u029f\3\2\2\2\u029c\u029e\5l\67\2\u029d\u029c\3\2"+
		"\2\2\u029e\u02a1\3\2\2\2\u029f\u029d\3\2\2\2\u029f\u02a0\3\2\2\2\u02a0"+
		"k\3\2\2\2\u02a1\u029f\3\2\2\2\u02a2\u02a3\6\67\21\2\u02a3\u02a4\n\5\2"+
		"\2\u02a4m\3\2\2\2\u02a5\u02a6\t\6\2\2\u02a6o\3\2\2\2\63w\u0083\u008a\u0096"+
		"\u00a5\u00b3\u00ca\u00de\u00eb\u00f3\u00fb\u0100\u0104\u010f\u0117\u011f"+
		"\u0126\u0131\u0140\u0142\u014e\u0150\u015d\u0168\u0173\u018c\u018e\u0196"+
		"\u01a2\u01a4\u01af\u01ba\u01cd\u01cf\u01d8\u01de\u01e6\u01ea\u01f9\u0201"+
		"\u0227\u022e\u0238\u0241\u024e\u0288\u0293\u029a\u029f";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}